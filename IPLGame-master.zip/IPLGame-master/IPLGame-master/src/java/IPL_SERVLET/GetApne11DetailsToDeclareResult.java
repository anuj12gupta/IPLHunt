package IPL_SERVLET;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import IPL_BEANS.MatchBean;
import IPL_BEANS.Player;
import IPL_LOGIC.MatchLogic;
import IPL_LOGIC.PlayerUtil;

/**
 * Servlet implementation class GetApne11DetailsToDeclareResult
 */
public class GetApne11DetailsToDeclareResult extends HttpServlet
{
  private static final long serialVersionUID = 1L;

  /**
   * @see HttpServlet#HttpServlet()
   */
  public GetApne11DetailsToDeclareResult()
  {
    super();
    // TODO Auto-generated constructor stub
  }

  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    String matchID = request.getParameter("matchID").trim();
    MatchBean matchBean = new MatchBean();
    matchBean.setMatchID(matchID);
    MatchLogic matchLogic = new MatchLogic(matchBean);
    matchBean = matchLogic.getMatchInfoById();

    PlayerUtil playerLogic = new PlayerUtil();
    List<Player> team1PlayerList = playerLogic.getPlayerListOfTeam(matchBean.getTeam1ID());
    List<Player> team2PlayerList = playerLogic.getPlayerListOfTeam(matchBean.getTeam2ID());
    playerLogic.closeConnection();

    request.setAttribute("team1PlayerList", team1PlayerList);
    request.setAttribute("team2PlayerList", team2PlayerList);

    request.setAttribute("matchId", matchID);
    RequestDispatcher dispatcher = request.getRequestDispatcher("ajx_declare_apne11_result_details.jsp");
    dispatcher.forward(request, response);
  }

  /**
   * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
   */
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    // TODO Auto-generated method stub
    doGet(request, response);
  }

}
