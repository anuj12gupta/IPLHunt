package IPL_SERVLET;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import IPL_BEANS.UserBean;
import IPL_LOGIC.Apne11Logic;

/**
 * Servlet implementation class SaveApne11Team
 */

public class SaveApne11Team extends HttpServlet
{
  private static final long serialVersionUID = 1L;

  /**
   * @see HttpServlet#HttpServlet()
   */
  public SaveApne11Team()
  {
    super();
    // TODO Auto-generated constructor stub
  }

  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    HttpSession session = request.getSession(true);
    UserBean userBean = new UserBean();

    try
    {
      userBean = (UserBean) session.getAttribute("userObject");
    }
    catch (NullPointerException npe)
    {
      RequestDispatcher dispatcher = request.getRequestDispatcher("../logout.jsp");
      dispatcher.forward(request, response);
    }

    List<String> playerIds = new ArrayList<>();
    for (int i = 0; i < 4; i++)
    {
      String value = request.getParameter("wkp" + (i + 1) + "id");
      if (value != null && !value.isEmpty())
      {
        playerIds.add(value);
      }
    }

    for (int i = 0; i < 6; i++)
    {
      String value = request.getParameter("btm" + (i + 1) + "id");
      if (value != null && !value.isEmpty())
      {
        playerIds.add(value);
      }
    }

    for (int i = 0; i < 4; i++)
    {
      String value = request.getParameter("alr" + (i + 1) + "id");
      if (value != null && !value.isEmpty())
      {
        playerIds.add(value);
      }
    }

    for (int i = 0; i < 6; i++)
    {
      String value = request.getParameter("bow" + (i + 1) + "id");
      if (value != null && !value.isEmpty())
      {
        playerIds.add(value);
      }
    }

    if (playerIds.size() < 11)
    {
      return;
    }

    String captain = request.getParameter("captain");
    String viceCaptain = request.getParameter("viceCaptain");

    if (captain == null || viceCaptain == null)
    {
      return;
    }

    String matchId = request.getParameter("selectedMatchID").trim();
    Apne11Logic apne11Logic = new Apne11Logic();
    String displayMessage = "";
    boolean flag = false;
    if (apne11Logic.isEntryPresent(matchId, userBean.getUserID()))
    {
      flag = apne11Logic.updateApne11Entry(matchId, userBean.getUserID(), playerIds, captain, viceCaptain);
      if (flag)
        displayMessage = "Team entry is updated successfully";
    }
    else
    {
      flag = apne11Logic.saveApne11Entry(matchId, userBean.getUserID(), playerIds, captain, viceCaptain);
      if (flag)
        displayMessage = "Team registered for apne11 contest";
      else
        displayMessage = "Technical Issue : Operation failed";
    }
    apne11Logic.closeConnection();
    session.setAttribute("displayMessage", displayMessage);
    RequestDispatcher dispatcher = request.getRequestDispatcher("player_bid_page.jsp");
    dispatcher.forward(request, response);
  }

  /**
   * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
   */
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    // TODO Auto-generated method stub
    doGet(request, response);
  }

}
