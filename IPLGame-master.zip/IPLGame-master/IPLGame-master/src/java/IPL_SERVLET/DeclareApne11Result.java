package IPL_SERVLET;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import IPL_BEANS.MatchBean;
import IPL_BEANS.Player;
import IPL_BEANS.TransactionBean;
import IPL_LOGIC.Apne11Logic;
import IPL_LOGIC.MatchLogic;
import IPL_LOGIC.PlayerUtil;
import IPL_LOGIC.TransactionLogic;
import IPL_LOGIC.UserLogic;
import IPL_UTILITY.MyServerDateTime;

/**
 * Servlet implementation class DeclareApne11Result
 */
public class DeclareApne11Result extends HttpServlet
{
  private static final long serialVersionUID = 1L;

  /**
   * @see HttpServlet#HttpServlet()
   */
  public DeclareApne11Result()
  {
    super();
    // TODO Auto-generated constructor stub
  }

  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    String player1IDs[] = request.getParameterValues("Player1ID");
    String player2IDs[] = request.getParameterValues("Player2ID");
    String matchId = request.getParameter("matchId");
    List<Player> playerList = new ArrayList<Player>();

    Apne11Logic apne11Logic = new Apne11Logic();
    PlayerUtil playerUtil = new PlayerUtil();
    TransactionBean trxBean = new TransactionBean();
    TransactionLogic trxLogic = new TransactionLogic(trxBean);
    for (int i = 0; i < player1IDs.length; i++)
    {
      String playerPlaying = request.getParameter("player1" + player1IDs[i] + "Playing");
      String playerPoints = request.getParameter("player1" + player1IDs[i] + "Point");

      Player player = new Player();
      player.setPlayerId(Integer.parseInt(player1IDs[i]));
      player.setPoint(Double.parseDouble(playerPoints));
      if (playerPlaying.equalsIgnoreCase("1"))
      {
        player.setPlaying(true);
        player.setPoint(Double.parseDouble(playerPoints));
      }
      else
      {
        player.setPlaying(false);
        player.setPoint(0.0);
      }
      playerUtil.updatePlayerPlayingStatus(Integer.toString(player.playerId), player.isPlaying());
      apne11Logic.saveApne11Result(matchId, Integer.toString(player.playerId), player.getPoint(), player.isPlaying() ? 1 : 0);
      playerList.add(player);
    }

    for (int i = 0; i < player2IDs.length; i++)
    {
      String playerPlaying = request.getParameter("player2" + player2IDs[i] + "Playing");
      String playerPoints = request.getParameter("player2" + player2IDs[i] + "Point");

      Player player = new Player();
      player.setPlayerId(Integer.parseInt(player2IDs[i]));

      if (playerPlaying.equalsIgnoreCase("1"))
      {
        player.setPlaying(true);
        player.setPoint(Double.parseDouble(playerPoints));
      }
      else
      {
        player.setPlaying(false);
        player.setPoint(0.0);
      }
      playerUtil.updatePlayerPlayingStatus(Integer.toString(player.playerId), player.isPlaying());
      apne11Logic.saveApne11Result(matchId, Integer.toString(player.playerId), player.getPoint(), player.isPlaying() ? 1 : 0);
      playerList.add(player);
    }

    Map<String, String[]> registeredMap = apne11Logic.apne11TeamsRegisteredForMatch(matchId);
    Set<Entry<String, String[]>> entrySet = registeredMap.entrySet();
    Iterator<Entry<String, String[]>> setItr = entrySet.iterator();
    UserLogic userLogic = new UserLogic();
    while (setItr.hasNext())
    {
      Entry<String, String[]> entryObj = setItr.next();
      String userId = entryObj.getKey();
      String teamIdList[] = entryObj.getValue();

      String trxTime = MyServerDateTime.getServerTime();
      String trxDate = MyServerDateTime.getServerDate();

      double userEarnedPoints = 0.0;

      for (int i = 0; i < teamIdList.length - 2; i++)
      {
        Iterator<Player> playerListItr = playerList.iterator();
        while (playerListItr.hasNext())
        {
          Player player = playerListItr.next();
          if (Integer.parseInt(teamIdList[i]) == player.playerId)
          {
            if (player.playerId == Integer.parseInt(teamIdList[11]))
              userEarnedPoints = userEarnedPoints + (2 * player.getPoint());
            else if (player.playerId == Integer.parseInt(teamIdList[12]))
              userEarnedPoints = userEarnedPoints + (1.5 * player.getPoint());
            else
              userEarnedPoints = userEarnedPoints + player.getPoint();
          }
        }
      }
      apne11Logic.updateApne11EntryTeamPoints(matchId, userId, String.valueOf(userEarnedPoints));
      double previousPoints = userLogic.getUserApne11Points(userId);
      double totalPoints = userEarnedPoints + previousPoints;
      userLogic.updateUserApne11Points(userId, totalPoints);

      trxBean.setUserID(userId);
      trxBean.setTrxType("CREDIT");
      trxBean.setTrxTitle("APNE11-GAIN#M" + matchId);
      trxBean.setTrxTime(trxTime);
      trxBean.setTrxDate(trxDate);
      trxBean.setTrxAmount(String.valueOf(userEarnedPoints));
      trxBean.setOpeningBalance(String.valueOf(previousPoints));
      trxBean.setClosingBalance(String.valueOf(totalPoints));
      trxLogic.saveApne11UserTransaction();
    }
    MatchBean matchBean = new MatchBean();
    matchBean.setMatchID(matchId);
    matchBean.setApne11Status("DECLARED");
    MatchLogic matchLogic = new MatchLogic(matchBean);
    matchLogic.updateApne11MatchStatus();
    matchLogic.closeConnection();
    apne11Logic.closeConnection();
    playerUtil.closeConnection();
    trxLogic.closeConnection();

    request.setAttribute("displayMessage", "APNE11 RESULT DECLARED");
    RequestDispatcher dispatcher = request.getRequestDispatcher("admin_declare_apne11_result.jsp");
    dispatcher.forward(request, response);
  }

  /**
   * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
   */
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    // TODO Auto-generated method stub
    doGet(request, response);
  }

}
