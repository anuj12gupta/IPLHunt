package IPL_AJAX_SERVLET;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import IPL_BEANS.MatchBean;
import IPL_BEANS.Player;
import IPL_BEANS.UserBean;
import IPL_LOGIC.Apne11Logic;
import IPL_LOGIC.MatchLogic;

/**
 * Servlet implementation class GetApne11ResultToDisplay
 */
public class GetApne11ResultToDisplay extends HttpServlet
{
  private static final long serialVersionUID = 1L;

  /**
   * @see HttpServlet#HttpServlet()
   */
  public GetApne11ResultToDisplay()
  {
    super();
    // TODO Auto-generated constructor stub
  }

  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    String matchID = request.getParameter("matchID").trim();
    MatchBean matchBean = new MatchBean();
    matchBean.setMatchID(matchID);
    MatchLogic matchLogic = new MatchLogic(matchBean);
    matchBean = matchLogic.getMatchInfoById();

    Apne11Logic apne11Logic = new Apne11Logic();
    List<Player> team1PlayerList = apne11Logic.getApne11TeamResult(matchBean.getMatchID(), matchBean.getTeam1ID());
    List<Player> team2PlayerList = apne11Logic.getApne11TeamResult(matchBean.getMatchID(), matchBean.getTeam2ID());
    List<UserBean> userList = apne11Logic.getApne11UsersListWithEarnedPoints(matchBean.getMatchID());

    request.setAttribute("team1PlayerList", team1PlayerList);
    request.setAttribute("team2PlayerList", team2PlayerList);
    request.setAttribute("userList", userList);
    request.setAttribute("team1Name", matchBean.getTeam1Name());
    request.setAttribute("team2Name", matchBean.getTeam2Name());
    request.setAttribute("matchId", matchID);
    apne11Logic.closeConnection();
    RequestDispatcher dispatcher = request.getRequestDispatcher("ajx_declared_apne11_details.jsp");
    dispatcher.forward(request, response);
  }

  /**
   * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
   */
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    // TODO Auto-generated method stub
    doGet(request, response);
  }

}
