package IPL_AJAX_SERVLET;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import IPL_BEANS.Allrounder;
import IPL_BEANS.Batsman;
import IPL_BEANS.Bowler;
import IPL_BEANS.MatchBean;
import IPL_BEANS.Player;
import IPL_BEANS.UserBean;
import IPL_BEANS.WicketKeeper;
import IPL_LOGIC.Apne11Logic;
import IPL_LOGIC.PlayerUtil;

/**
 * Servlet implementation class GetApne11Details
 */
public class GetApne11Details extends HttpServlet
{
  private static final long serialVersionUID = 1L;

  /**
   * @see HttpServlet#HttpServlet()
   */
  public GetApne11Details()
  {
    super();
    // TODO Auto-generated constructor stub
  }

  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    String matchIDRequest = request.getParameter("matchID").trim();

    MatchBean matchBeanFinal = new MatchBean();
    HttpSession session = request.getSession();
    ArrayList<MatchBean> matchList = (ArrayList<MatchBean>) session.getAttribute("matchList");
    UserBean userBean = (UserBean) session.getAttribute("userObject");

    Iterator<MatchBean> itr = matchList.iterator();
    while (itr.hasNext())
    {
      MatchBean matchBean = itr.next();
      String matchID = matchBean.getMatchID();
      if (matchID.equals(matchIDRequest))
      {
        matchBeanFinal = matchBean;
      }
    }

    PlayerUtil playerUtil = new PlayerUtil();
    List<Player> playerList = playerUtil.getPlayingPlayerListOfMatch(matchBeanFinal.getTeam1ID(), matchBeanFinal.getTeam2ID());
    request.setAttribute("playerList", playerList);
    request.setAttribute("matchDetails", matchBeanFinal);

    Apne11Logic apne11Logic = new Apne11Logic();
    String userSelectedList[] = null;
    Set<Integer> playerIdset = new HashSet<>();
    List<Player> selectedList = new ArrayList<>();

    Double creditRemaining = 100.0;
    Integer team1Count = 0, team2Count = 0, wkpCount = 0, btmCount = 0, alrCount = 0, bowCount = 0;
    Integer captainID = 0, viceCaptainID = 0;
    List<Player> wkpList = new ArrayList<>();
    List<Player> btmList = new ArrayList<>();
    List<Player> alrList = new ArrayList<>();
    List<Player> bowList = new ArrayList<>();
    if (apne11Logic.isEntryPresent(matchBeanFinal.getMatchID(), userBean.getUserID()))
    {
      userSelectedList = apne11Logic.userSelectedPlayerIdList(matchBeanFinal.getMatchID(), userBean.getUserID());

      for (int i = 0; i < userSelectedList.length; i++)
      {
        Iterator<Player> listItr = playerList.iterator();
        while (listItr.hasNext())
        {
          Player player = listItr.next();

          if (player.getPlayerId() == Integer.parseInt(userSelectedList[i]))
          {
            playerIdset.add(player.getPlayerId());
            selectedList.add(player);
            if (i < 11)
            {
              if (player.team.getTeamCode().equals(matchBeanFinal.getTeam1Code()))
                team1Count++;
              else
                team2Count++;

              if (player instanceof WicketKeeper)
              {
                wkpCount++;
                wkpList.add(player);
              }
              else if (player instanceof Batsman)
              {
                btmCount++;
                btmList.add(player);
              }
              else if (player instanceof Allrounder)
              {
                alrCount++;
                alrList.add(player);
              }
              else if (player instanceof Bowler)
              {
                bowCount++;
                bowList.add(player);
              }

              creditRemaining = creditRemaining - player.getPoint();
            }

          }

        }

      }

      captainID = selectedList.get(11).getPlayerId();

      viceCaptainID = selectedList.get(12).getPlayerId();
    }

    request.setAttribute("team1Count", team1Count);
    request.setAttribute("team2Count", team2Count);

    request.setAttribute("captainID", captainID);
    request.setAttribute("viceCaptainID", viceCaptainID);

    request.setAttribute("wkpList", wkpList);
    request.setAttribute("btmList", btmList);
    request.setAttribute("alrList", alrList);
    request.setAttribute("bowList", bowList);

    request.setAttribute("wkpCount", wkpCount);
    request.setAttribute("btmCount", btmCount);
    request.setAttribute("alrCount", alrCount);
    request.setAttribute("bowCount", bowCount);

    request.setAttribute("creditRemaining", creditRemaining);

    request.setAttribute("playerIdset", playerIdset);
    apne11Logic.closeConnection();
    request.setAttribute("selectedList", selectedList);
    RequestDispatcher dispatcher = request.getRequestDispatcher("ajx_apne11_detail_page.jsp");
    dispatcher.forward(request, response);
  }

  /**
   * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
   */
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {

    doGet(request, response);
  }

}
