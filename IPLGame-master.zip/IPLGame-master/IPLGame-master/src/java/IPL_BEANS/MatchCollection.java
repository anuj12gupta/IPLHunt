/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package IPL_BEANS;

/**
 *
 * @author Abhinav Kumar
 */
public class MatchCollection {
    
    String matchID;
    String userID;
    String amount;
    String bidDate;
    String bidTime;
    String bidTeam;
    String collectionID;
    String resultAmount;
    String colStatus;
    String winTeamID;
    String loseTeamID;
    String team1Amount;
    String team2Amount;
    String team1ID;
    String team2ID;

    public String getMatchID() {
        return matchID;
    }

    public void setMatchID(String matchID) {
        this.matchID = matchID;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getBidDate() {
        return bidDate;
    }

    public void setBidDate(String bidDate) {
        this.bidDate = bidDate;
    }

    public String getBidTime() {
        return bidTime;
    }

    public void setBidTime(String bidTime) {
        this.bidTime = bidTime;
    }

    public String getBidTeam() {
        return bidTeam;
    }

    public void setBidTeam(String bidTeam) {
        this.bidTeam = bidTeam;
    }

    public String getCollectionID() {
        return collectionID;
    }

    public void setCollectionID(String collectionID) {
        this.collectionID = collectionID;
    }

    public String getResultAmount() {
        return resultAmount;
    }

    public void setResultAmount(String resultAmount) {
        this.resultAmount = resultAmount;
    }

    public String getColStatus() {
        return colStatus;
    }

    public void setColStatus(String colStatus) {
        this.colStatus = colStatus;
    }

    public String getWinTeamID() {
        return winTeamID;
    }

    public void setWinTeamID(String winTeamID) {
        this.winTeamID = winTeamID;
    }

    public String getLoseTeamID() {
        return loseTeamID;
    }

    public void setLoseTeamID(String loseTeamID) {
        this.loseTeamID = loseTeamID;
    }

    public String getTeam1Amount() {
        return team1Amount;
    }

    public void setTeam1Amount(String team1Amount) {
        this.team1Amount = team1Amount;
    }

    public String getTeam2Amount() {
        return team2Amount;
    }

    public void setTeam2Amount(String team2Amount) {
        this.team2Amount = team2Amount;
    }  

    public String getTeam1ID() {
        return team1ID;
    }

    public void setTeam1ID(String team1ID) {
        this.team1ID = team1ID;
    }

    public String getTeam2ID() {
        return team2ID;
    }

    public void setTeam2ID(String team2ID) {
        this.team2ID = team2ID;
    }
}
