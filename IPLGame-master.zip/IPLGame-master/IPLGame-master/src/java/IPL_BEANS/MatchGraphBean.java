/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package IPL_BEANS;

/**
 *
 * @author Abhinav Kumar
 */
public class MatchGraphBean {

    String matchId;
    String teamId;
    String teamAmount;
    String teamCount;

    public String getMatchId() {
        return matchId;
    }

    public void setMatchId(String matchId) {
        this.matchId = matchId;
    }

    public String getTeamId() {
        return teamId;
    }

    public void setTeamId(String teamId) {
        this.teamId = teamId;
    }

    public String getTeamAmount() {
        return teamAmount;
    }

    public void setTeamAmount(String teamAmount) {
        this.teamAmount = teamAmount;
    }

    public String getTeamCount() {
        return teamCount;
    }

    public void setTeamCount(String teamCount) {
        this.teamCount = teamCount;
    }
}
