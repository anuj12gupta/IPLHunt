package IPL_BEANS;

public class WicketKeeper extends Player
{
  public WicketKeeper(int id, String name, double point, boolean playing, int teamId)
  {
    super(id, name, point, playing, teamId);
  }
}
