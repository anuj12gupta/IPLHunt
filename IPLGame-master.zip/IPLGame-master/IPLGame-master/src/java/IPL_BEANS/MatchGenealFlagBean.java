/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package IPL_BEANS;

/**
 *
 * @author Abhinav Kumar
 */
public class MatchGenealFlagBean {

    String matchType;
    String matchMinBidAmount;
    String matchBidPercentage;
    String matchBidBothSide;
    String matchNBUFineAmount;
    String matchNBUFinePercentage;
    String matchQuestionAmount;

    public String getMatchType() {
        return matchType;
    }

    public void setMatchType(String matchType) {
        this.matchType = matchType;
    }

    public String getMatchMinBidAmount() {
        return matchMinBidAmount;
    }

    public void setMatchMinBidAmount(String matchMinBidAmount) {
        this.matchMinBidAmount = matchMinBidAmount;
    }

    public String getMatchBidPercentage() {
        return matchBidPercentage;
    }

    public void setMatchBidPercentage(String matchBidPercentage) {
        this.matchBidPercentage = matchBidPercentage;
    }

    public String getMatchBidBothSide() {
        return matchBidBothSide;
    }

    public void setMatchBidBothSide(String matchBidBothSide) {
        this.matchBidBothSide = matchBidBothSide;
    }

    public String getMatchNBUFineAmount() {
        return matchNBUFineAmount;
    }

    public void setMatchNBUFineAmount(String matchNBUFineAmount) {
        this.matchNBUFineAmount = matchNBUFineAmount;
    }

    public String getMatchNBUFinePercentage() {
        return matchNBUFinePercentage;
    }

    public void setMatchNBUFinePercentage(String matchNBUFinePercentage) {
        this.matchNBUFinePercentage = matchNBUFinePercentage;
    }

    public String getMatchQuestionAmount() {
        return matchQuestionAmount;
    }

    public void setMatchQuestionAmount(String matchQuestionAmount) {
        this.matchQuestionAmount = matchQuestionAmount;
    }
}
