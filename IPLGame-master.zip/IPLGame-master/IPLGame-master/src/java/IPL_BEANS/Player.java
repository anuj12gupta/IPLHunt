package IPL_BEANS;

public class Player
{
  public int playerId;
  public String name;
  public double point;
  public boolean playing;
  public double earnedPoints;
  public TeamBean team;
  public String playerType;
  public boolean isCaptain;
  public boolean isViceCaptain;

  public Player()
  {

  }

  public Player(int id, String name, double point, boolean playing, int teamId)
  {
    this.playerId = id;
    this.name = name;
    this.point = point;
    this.playing = playing;
    team = new TeamBean();
    team.setTeamID(Integer.toString(teamId));
  }

  public int getPlayerId()
  {
    return playerId;
  }

  public void setPlayerId(int playerId)
  {
    this.playerId = playerId;
  }

  public String getName()
  {
    return name;
  }

  public void setName(String name)
  {
    this.name = name;
  }

  public double getPoint()
  {
    return point;
  }

  public void setPoint(double point)
  {
    this.point = point;
  }

  public boolean isPlaying()
  {
    return playing;
  }

  public void setPlaying(boolean playing)
  {
    this.playing = playing;
  }

  public TeamBean getTeam()
  {
    return team;
  }

  public void setTeam(TeamBean team)
  {
    this.team = team;
  }

  public double getEarnedPoints()
  {
    return earnedPoints;
  }

  public void setEarnedPoints(double earnedPoints)
  {
    this.earnedPoints = earnedPoints;
  }

  public String getPlayerType()
  {
    return playerType;
  }

  public void setPlayerType(String playerType)
  {
    this.playerType = playerType;
  }

  public boolean isCaptain()
  {
    return isCaptain;
  }

  public void setCaptain(boolean isCaptain)
  {
    this.isCaptain = isCaptain;
  }

  public boolean isViceCaptain()
  {
    return isViceCaptain;
  }

  public void setViceCaptain(boolean isViceCaptain)
  {
    this.isViceCaptain = isViceCaptain;
  }
}
