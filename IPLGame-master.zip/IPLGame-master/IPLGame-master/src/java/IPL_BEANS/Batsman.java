package IPL_BEANS;

public class Batsman extends Player
{
  public Batsman(int id, String name, double point, boolean playing, int teamId)
  {
    super(id, name, point, playing, teamId);
  }
}
