package IPL_BEANS;

public class MatchBean
{

  String matchID;
  String team1ID;
  String team2ID;
  String matchDate;
  String roundType;
  String startTime;
  String matchStatus;
  String matchDay;
  ResultBean resultBean;
  String team1Name;
  String team2Name;
  String team1Code;
  String team2Code;
  String team1Collection;
  String team2Collection;
  String apne11Status;

  UserBean userBean;

  public String getMatchID()
  {
    return matchID;
  }

  public void setMatchID(String matchID)
  {
    this.matchID = matchID;
  }

  public String getTeam1ID()
  {
    return team1ID;
  }

  public void setTeam1ID(String team1ID)
  {
    this.team1ID = team1ID;
  }

  public String getTeam2ID()
  {
    return team2ID;
  }

  public void setTeam2ID(String team2ID)
  {
    this.team2ID = team2ID;
  }

  public String getMatchDate()
  {
    return matchDate;
  }

  public void setMatchDate(String matchDate)
  {
    this.matchDate = matchDate;
  }

  public String getRoundType()
  {
    return roundType;
  }

  public void setRoundType(String roundType)
  {
    this.roundType = roundType;
  }

  public String getStartTime()
  {
    return startTime;
  }

  public void setStartTime(String startTime)
  {
    this.startTime = startTime;
  }

  public String getMatchStatus()
  {
    return matchStatus;
  }

  public void setMatchStatus(String matchStatus)
  {
    this.matchStatus = matchStatus;
  }

  public String getMatchDay()
  {
    return matchDay;
  }

  public void setMatchDay(String matchDay)
  {
    this.matchDay = matchDay;
  }

  public ResultBean getResultBean()
  {
    return resultBean;
  }

  public void setResultBean(ResultBean resultBean)
  {
    this.resultBean = resultBean;
  }

  public String getTeam1Name()
  {
    return team1Name;
  }

  public void setTeam1Name(String team1Name)
  {
    this.team1Name = team1Name;
  }

  public String getTeam2Name()
  {
    return team2Name;
  }

  public void setTeam2Name(String team2Name)
  {
    this.team2Name = team2Name;
  }

  public String getTeam1Collection()
  {
    return team1Collection;
  }

  public void setTeam1Collection(String team1Collection)
  {
    this.team1Collection = team1Collection;
  }

  public String getTeam2Collection()
  {
    return team2Collection;
  }

  public void setTeam2Collection(String team2Collection)
  {
    this.team2Collection = team2Collection;
  }

  public UserBean getUserBean()
  {
    return userBean;
  }

  public void setUserBean(UserBean userBean)
  {
    this.userBean = userBean;
  }

  public String getTeam1Code()
  {
    return team1Code;
  }

  public void setTeam1Code(String team1Code)
  {
    this.team1Code = team1Code;
  }

  public String getTeam2Code()
  {
    return team2Code;
  }

  public void setTeam2Code(String team2Code)
  {
    this.team2Code = team2Code;
  }

  public String getApne11Status()
  {
    return apne11Status;
  }

  public void setApne11Status(String apne11Status)
  {
    this.apne11Status = apne11Status;
  }
}
