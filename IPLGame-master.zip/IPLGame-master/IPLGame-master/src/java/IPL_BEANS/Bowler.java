package IPL_BEANS;

public class Bowler extends Player
{
  public Bowler(int id, String name, double point, boolean playing, int teamId)
  {
    super(id, name, point, playing, teamId);
  }
}