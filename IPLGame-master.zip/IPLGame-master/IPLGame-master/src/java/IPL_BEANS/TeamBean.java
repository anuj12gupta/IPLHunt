/*
 * To change this template, choose Tools | Templates and open the template in the editor.
 */
package IPL_BEANS;

/**
 *
 * @author Abhinav Kumar
 */
public class TeamBean
{

  String teamID;
  String teamName;
  String playerName;
  String teamCode;

  public String getTeamID()
  {
    return teamID;
  }

  public void setTeamID(String teamID)
  {
    this.teamID = teamID;
  }

  public String getTeamName()
  {
    return teamName;
  }

  public void setTeamName(String teamName)
  {
    this.teamName = teamName;
  }

  public String getPlayerName()
  {
    return playerName;
  }

  public void setPlayerName(String playerName)
  {
    this.playerName = playerName;
  }

  public String getTeamCode()
  {
    return teamCode;
  }

  public void setTeamCode(String teamCode)
  {
    this.teamCode = teamCode;
  }
}
