package IPL_BEANS;

public class Allrounder extends Player
{
  public Allrounder(int id, String name, double point, boolean playing, int teamId)
  {
    super(id, name, point, playing, teamId);
  }
}