package IPL_LOGIC;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import IPL_BEANS.MatchBean;
import IPL_BEANS.Player;
import IPL_BEANS.UserBean;
import IPL_DAO.Apne11Dao;

public class Apne11Logic
{
  Apne11Dao apne11Dao;

  public Apne11Logic()
  {
    apne11Dao = new Apne11Dao();
  }

  public boolean isEntryPresent(String matchId, String userId)
  {
    boolean isPresent = false;
    try
    {
      ResultSet result = apne11Dao.getUserApne11TeamForMatch(matchId, userId);
      if (result.next())
      {
        isPresent = true;
      }
    }
    catch (Exception exp)
    {
      System.out
          .println("Apne11Logic:isEntryPresent: Exception occured " + "while fetching team player entry is present for apne 11 contest, Please check below message " + "for more details : \n" + exp);
    }
    return isPresent;
  }

  public boolean saveApne11Entry(String matchId, String userId, List<String> playerIds, String captainId, String viceCaptainId)
  {
    String playerIDArr[] = convertListToArray(playerIds);
    playerIDArr[11] = captainId;
    playerIDArr[12] = viceCaptainId;
    int saveCount = apne11Dao.saveApne11Entry(matchId, userId, playerIDArr);
    if (saveCount > 0)
      return true;
    return false;
  }

  public boolean updateApne11Entry(String matchId, String userId, List<String> playerIds, String captainId, String viceCaptainId)
  {
    String playerIDArr[] = convertListToArray(playerIds);
    playerIDArr[11] = captainId;
    playerIDArr[12] = viceCaptainId;
    int updateCount = apne11Dao.updateApne11Entry(matchId, userId, playerIDArr);
    if (updateCount > 0)
      return true;
    return false;

  }

  public boolean updateApne11EntryTeamPoints(String matchId, String userId, String points)
  {
    int updateCount = apne11Dao.updateApne11TeamPoints(matchId, userId, points);
    if (updateCount > 0)
      return true;
    return false;
  }

  public String[] convertListToArray(List<String> playerIds)
  {
    String playerList[] = new String[13];
    Iterator<String> listItr = playerIds.iterator();
    int i = 0;
    while (listItr.hasNext())
    {
      playerList[i] = listItr.next();
      i++;
    }
    return playerList;
  }

  public String[] userSelectedPlayerIdList(String matchId, String userId)
  {
    ResultSet result = apne11Dao.getUserApne11TeamForMatch(matchId, userId);
    String selectedList[] = new String[13];
    try
    {
      while (result.next())
      {
        selectedList[0] = result.getString("PLAYER_1_ID");
        selectedList[1] = result.getString("PLAYER_2_ID");
        selectedList[2] = result.getString("PLAYER_3_ID");
        selectedList[3] = result.getString("PLAYER_4_ID");
        selectedList[4] = result.getString("PLAYER_5_ID");
        selectedList[5] = result.getString("PLAYER_6_ID");
        selectedList[6] = result.getString("PLAYER_7_ID");
        selectedList[7] = result.getString("PLAYER_8_ID");
        selectedList[8] = result.getString("PLAYER_9_ID");
        selectedList[9] = result.getString("PLAYER_10_ID");
        selectedList[10] = result.getString("PLAYER_11_ID");
        selectedList[11] = result.getString("CAPTAIN_ID");
        selectedList[12] = result.getString("VCAPTAIN_ID");
      }
    }
    catch (Exception exp)
    {
      System.out.println("Apne11Logic:userSelectedPlayerIdList: Exception occured while preparing user selected list " + exp);
    }
    return selectedList;
  }

  public Map<String, String[]> apne11TeamsRegisteredForMatch(String matchId)
  {
    ResultSet result = apne11Dao.getApne11RegisteredTeamForMatch(matchId);

    Map<String, String[]> apne11RegisteredMap = new HashMap<>();
    try
    {
      while (result.next())
      {
        String selectedList[] = new String[13];
        selectedList[0] = result.getString("PLAYER_1_ID");
        selectedList[1] = result.getString("PLAYER_2_ID");
        selectedList[2] = result.getString("PLAYER_3_ID");
        selectedList[3] = result.getString("PLAYER_4_ID");
        selectedList[4] = result.getString("PLAYER_5_ID");
        selectedList[5] = result.getString("PLAYER_6_ID");
        selectedList[6] = result.getString("PLAYER_7_ID");
        selectedList[7] = result.getString("PLAYER_8_ID");
        selectedList[8] = result.getString("PLAYER_9_ID");
        selectedList[9] = result.getString("PLAYER_10_ID");
        selectedList[10] = result.getString("PLAYER_11_ID");
        selectedList[11] = result.getString("CAPTAIN_ID");
        selectedList[12] = result.getString("VCAPTAIN_ID");
        String userId = new String();
        userId = result.getString("USER_ID");
        apne11RegisteredMap.put(userId, selectedList);

      }
    }
    catch (Exception exp)
    {
      System.out.println("Apne11Logic:apne11TeamsRegisteredForMatch: Exception occured while preparing user selected list " + exp);
    }
    return apne11RegisteredMap;
  }

  public boolean saveApne11Result(String matchId, String playerId, double playerPoints, int playingStatus)
  {
    int saveCount = apne11Dao.saveApne11Result(matchId, playerId, playerPoints, playingStatus);
    if (saveCount > 0)
      return true;
    return false;
  }

  public List<Player> getApne11TeamResult(String matchId, String teamId)
  {
    ResultSet result = apne11Dao.getApne11TeamResult(matchId, teamId);
    ArrayList<Player> playerList = new ArrayList<>();
    try
    {
      while (result.next())
      {
        Player player = new Player();
        player.setName(result.getString("PLAYER_NAME"));
        player.setPlayerId(result.getInt("PLAYER_ID"));
        player.setEarnedPoints(result.getDouble("PLAYER_EARN_POINTS"));
        player.setPlayerType(result.getString("PLAYER_TYPE"));
        String playingStatus = result.getString("PLAYER_PLAYING");
        if (playingStatus.equalsIgnoreCase("1"))
          player.setPlaying(true);
        else
          player.setPlaying(false);
        playerList.add(player);
      }
    }
    catch (Exception exp)
    {
      System.out.println("Apne11Logic:getApne11TeamResult: Exception occured while preparing user selected list " + exp);
    }
    return playerList;
  }
  /*
   * public Map<UserBean, String[]> getApne11UsersTeamForMatch(String matchId) { ResultSet result = apne11Dao.getApne11UsersTeamForMatch(matchId);
   * 
   * Map<UserBean, String[]> apne11RegisteredMap = new HashMap<>(); try { while (result.next()) { String selectedList[] = new String[13]; selectedList[0] = result.getString("PLAYER_1_ID");
   * selectedList[1] = result.getString("PLAYER_2_ID"); selectedList[2] = result.getString("PLAYER_3_ID"); selectedList[3] = result.getString("PLAYER_4_ID"); selectedList[4] =
   * result.getString("PLAYER_5_ID"); selectedList[5] = result.getString("PLAYER_6_ID"); selectedList[6] = result.getString("PLAYER_7_ID"); selectedList[7] = result.getString("PLAYER_8_ID");
   * selectedList[8] = result.getString("PLAYER_9_ID"); selectedList[9] = result.getString("PLAYER_10_ID"); selectedList[10] = result.getString("PLAYER_11_ID"); selectedList[11] =
   * result.getString("CAPTAIN_ID"); selectedList[12] = result.getString("VCAPTAIN_ID"); UserBean user = new UserBean(); user.setUserID(result.getString("USER_ID"));
   * user.setUserFullname(result.getString("FULL_NAME")); apne11RegisteredMap.put(user, selectedList);
   * 
   * } } catch (Exception exp) { System.out.println("Apne11Logic:getApne11UsersTeamForMatch: Exception occured while preparing user selected list " + exp); } return apne11RegisteredMap; }
   */

  public List<UserBean> getApne11UsersListWithEarnedPoints(String matchId)
  {
    ResultSet result = apne11Dao.getApne11UsersTeamForMatch(matchId);
    List<UserBean> userList = new ArrayList<>();
    try
    {
      while (result.next())
      {
        UserBean user = new UserBean();
        user.setUserID(result.getString("USER_ID"));
        user.setUserFullname(result.getString("FULL_NAME"));
        user.setUserApne11Points(result.getString("TOTAL_POINTS"));
        user.setUserApne11Id(result.getString("APNE11_TEAM_ID"));
        userList.add(user);
      }
    }
    catch (Exception exp)
    {
      System.out.println("Apne11Logic:getApne11UsersListWithEarnedPoints: Exception occured while preparing user selected list " + exp);
    }

    return userList;
  }

  public List<Player> getApne11TeamDetails(String matchId, String userId)
  {
    // NEXT SEASON THIS TO BE IN MEMORY MAP
    MatchBean matchBean = new MatchBean();
    matchBean.setMatchID(matchId.trim());
    MatchLogic matchLogic = new MatchLogic(matchBean);
    matchBean = matchLogic.getMatchInfoById();
    List<Player> team1PlayerList = getApne11TeamResult(matchBean.getMatchID(), matchBean.getTeam1ID());
    List<Player> team2PlayerList = getApne11TeamResult(matchBean.getMatchID(), matchBean.getTeam2ID());
    List<Player> userTeam = new ArrayList<>();
    Map<String, String[]> registeredMap = apne11TeamsRegisteredForMatch(matchId);
    Set<Entry<String, String[]>> entrySet = registeredMap.entrySet();
    Iterator<Entry<String, String[]>> setItr = entrySet.iterator();
    while (setItr.hasNext())
    {
      Entry<String, String[]> entryObj = setItr.next();
      String userID = entryObj.getKey();
      String teamIdList[] = entryObj.getValue();

      if (userID.equalsIgnoreCase(userId))
      {
        for (int i = 0; i < teamIdList.length - 2; i++)
        {
          Iterator<Player> listItr = team1PlayerList.iterator();
          while (listItr.hasNext())
          {
            Player player = listItr.next();
            if (player.getPlayerId() == Integer.parseInt(teamIdList[i]))
            {
              if (teamIdList[i].equalsIgnoreCase(teamIdList[11]))
                player.setCaptain(true);
              else
                player.setCaptain(false);
              if (teamIdList[i].equalsIgnoreCase(teamIdList[12]))
                player.setViceCaptain(true);
              else
                player.setViceCaptain(false);
              userTeam.add(player);
            }
          }

          listItr = team2PlayerList.iterator();
          while (listItr.hasNext())
          {
            Player player = listItr.next();
            if (player.getPlayerId() == Integer.parseInt(teamIdList[i]))
            {
              if (teamIdList[i].equalsIgnoreCase(teamIdList[11]))
                player.setCaptain(true);
              else
                player.setCaptain(false);
              if (teamIdList[i].equalsIgnoreCase(teamIdList[12]))
                player.setViceCaptain(true);
              else
                player.setViceCaptain(false);
              userTeam.add(player);
            }
          }
        }
      }

    }
    return userTeam;
  }

  public void closeConnection()
  {
    try
    {
      apne11Dao.stmt.close();
      apne11Dao.con.close();
    }
    catch (Exception exp)
    {
      System.out.println("Apne11Logic:closeConnection: Exception occured while closing the connection " + exp);
    }
  }

}
