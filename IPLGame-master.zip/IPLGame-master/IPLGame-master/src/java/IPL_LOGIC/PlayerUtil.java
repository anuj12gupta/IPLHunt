package IPL_LOGIC;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import IPL_BEANS.Allrounder;
import IPL_BEANS.Batsman;
import IPL_BEANS.Bowler;
import IPL_BEANS.Player;
import IPL_BEANS.TeamBean;
import IPL_BEANS.WicketKeeper;
import IPL_DAO.PlayerDao;
import IPL_ENUMS.PlayerType;

public class PlayerUtil
{
  Player player;
  PlayerDao playerDao;

  public PlayerUtil()
  {
    playerDao = new PlayerDao();
  }

  public PlayerUtil(Player player)
  {
    this.player = player;
    playerDao = new PlayerDao(this.player);
  }

  public static Player getPlayerById(List<Player> playerList, int playerId)
  {
    for (Player player : playerList)
      if (player.getPlayerId() == playerId)
        return player;
    return null;
  }

  public static void removePlayerType(List<Player> playerList, PlayerType type)
  {
    switch (type)
    {
      case WICKETKEEPER:
        removeWicketKeeperfromList(playerList);
        break;

      case BATSMAN:
        removeBatsmanfromList(playerList);
        break;

      case ALLROUNDER:
        removeAllrounderfromList(playerList);
        break;

      case BOWLER:
        removeBowlerfromList(playerList);
        break;
    }
  }

  public static void removeWicketKeeperfromList(List<Player> playerList)
  {
    Iterator<Player> itr = playerList.iterator();
    while (itr.hasNext())
    {
      Player player = itr.next();
      if (player instanceof WicketKeeper)
        itr.remove();
    }
  }

  public static void removeBatsmanfromList(List<Player> playerList)
  {
    Iterator<Player> itr = playerList.iterator();
    while (itr.hasNext())
    {
      Player player = itr.next();
      if (player instanceof Batsman)
        itr.remove();
    }
  }

  public static void removeAllrounderfromList(List<Player> playerList)
  {
    Iterator<Player> itr = playerList.iterator();
    while (itr.hasNext())
    {
      Player player = itr.next();
      if (player instanceof Allrounder)
        itr.remove();
    }
  }

  public static void removeBowlerfromList(List<Player> playerList)
  {
    Iterator<Player> itr = playerList.iterator();
    while (itr.hasNext())
    {
      Player player = itr.next();
      if (player instanceof Bowler)
        itr.remove();
    }
  }

  public static int getPlayerofTeamCount(List<Player> playerList, int teamId)
  {
    int count = 0;
    Iterator<Player> itr = playerList.iterator();
    while (itr.hasNext())
    {
      Player player = itr.next();
      if (Integer.parseInt(player.getTeam().getTeamID()) == teamId)
        count++;
    }
    return count;
  }

  public static boolean isPlayerPointSumUnderCreditLimit(List<Player> playerList)
  {
    double pointSum = 0.0;
    Iterator<Player> itr = playerList.iterator();
    while (itr.hasNext())
    {
      Player player = itr.next();
      pointSum = pointSum + player.getPoint();
    }
    return pointSum <= 100.0 ? true : false;
  }

  public List<Player> getPlayingPlayerListOfMatch(String teamId1, String teamId2)
  {
    ResultSet result = playerDao.getPlayingPlayerListOfMatch(teamId1, teamId2);
    List<Player> playerList = new ArrayList<>();
    try
    {
      while (result.next())
      {
        Player player;

        int playerId = result.getInt("PLAYER_ID");
        int teamId = result.getInt("TEAM_ID");
        String playerName = result.getString("PLAYER_NAME");
        int playerPlaying = result.getInt("PLAYER_PLAYING");
        double playerPoints = result.getDouble("PLAYER_POINT");
        String playerType = result.getString("PLAYER_TYPE");
        String teamName = result.getString("TEAM_NAME");
        String teamCode = result.getString("TEAM_CODE");
        TeamBean team = new TeamBean();
        team.setTeamID(Integer.toString(teamId));
        team.setTeamCode(teamCode);
        team.setTeamName(teamName);
        if (playerType.equals("WICKETKEEPER"))
        {
          player = new WicketKeeper(playerId, playerName, playerPoints, playerPlaying == 0 ? false : true, teamId);
        }
        else if (playerType.equals("BATSMAN"))
        {
          player = new Batsman(playerId, playerName, playerPoints, playerPlaying == 0 ? false : true, teamId);
        }
        else if (playerType.equals("ALLROUNDER"))
        {
          player = new Allrounder(playerId, playerName, playerPoints, playerPlaying == 0 ? false : true, teamId);
        }
        else
        {
          player = new Bowler(playerId, playerName, playerPoints, playerPlaying == 0 ? false : true, teamId);
        }
        player.setTeam(team);
        playerList.add(player);
      }
      playerDao.stmt.close();
      playerDao.con.close();
    }
    catch (SQLException sqlException)
    {
      System.out.println("PlayerUtil:getPlayingPlayerListOfMatch: Exception occured " + "while preparing player list is : \n " + sqlException);
    }
    return playerList;
  }

  public List<Player> getPlayerListOfTeam(String teamID)
  {
    ResultSet result = playerDao.getPlayerListOfTeam(teamID);
    List<Player> playerList = new ArrayList<>();
    try
    {
      while (result.next())
      {
        Player player;

        int playerId = result.getInt("PLAYER_ID");
        int teamId = result.getInt("TEAM_ID");
        String playerName = result.getString("PLAYER_NAME");
        int playerPlaying = result.getInt("PLAYER_PLAYING");
        double playerPoints = result.getDouble("PLAYER_POINT");
        String playerType = result.getString("PLAYER_TYPE");
        String teamName = result.getString("TEAM_NAME");
        String teamCode = result.getString("TEAM_CODE");
        TeamBean team = new TeamBean();
        team.setTeamID(Integer.toString(teamId));
        team.setTeamCode(teamCode);
        team.setTeamName(teamName);
        if (playerType.equals("WICKETKEEPER"))
        {
          player = new WicketKeeper(playerId, playerName, playerPoints, playerPlaying == 0 ? false : true, teamId);
        }
        else if (playerType.equals("BATSMAN"))
        {
          player = new Batsman(playerId, playerName, playerPoints, playerPlaying == 0 ? false : true, teamId);
        }
        else if (playerType.equals("ALLROUNDER"))
        {
          player = new Allrounder(playerId, playerName, playerPoints, playerPlaying == 0 ? false : true, teamId);
        }
        else
        {
          player = new Bowler(playerId, playerName, playerPoints, playerPlaying == 0 ? false : true, teamId);
        }
        player.setTeam(team);
        playerList.add(player);
      }

    }
    catch (SQLException sqlException)
    {
      System.out.println("PlayerUtil:getPlayerListOfTeam: Exception occured " + "while preparing player list is : \n " + sqlException);
    }
    return playerList;
  }

  public boolean updatePlayerPlayingStatus(String playerId, boolean playingStatus)
  {
    int saveCount = playerDao.updatePlayerPlayingStatus(playerId, playingStatus ? "1" : "0");
    if (saveCount > 0)
      return true;
    return false;
  }

  public void closeConnection()
  {
    try
    {
      playerDao.stmt.close();
      playerDao.con.close();
    }
    catch (Exception exp)
    {
      System.out.println("PlayerUtil:closeConnection");
    }
  }
}
