package IPL_UTILITY;

/*
 * import org.apache.poi.ss.usermodel.Cell; import org.apache.poi.ss.usermodel.Row; import org.apache.poi.ss.usermodel.Sheet; import org.apache.poi.xssf.usermodel.XSSFWorkbook;
 */

public class ExcelToDB
{
  public static void main(String[] args)
  {
    /*
     * String excelFilePath = "C:/Data/Team_Details.xlsx";
     * 
     * int batchSize = 100;
     * 
     * Connection connection = null;
     * 
     * try {
     * 
     * // Create Workbook instance holding reference to .xlsx file // XSSFWorkbook workbook = new XSSFWorkbook(file);
     * 
     * // Get first/desired sheet from the workbook // XSSFSheet sheet = workbook.getSheetAt(0);
     * 
     * long start = System.currentTimeMillis();
     * 
     * FileInputStream inputStream = new FileInputStream(excelFilePath); XSSFWorkbook workbook = new XSSFWorkbook(inputStream); // Workbook workbook = new XSSFWorkbook(inputStream);
     * 
     * Sheet firstSheet = workbook.getSheetAt(4); Iterator<Row> rowIterator = firstSheet.iterator();
     * 
     * connection = IplBidConnection.openConnection();
     * 
     * String sql = "INSERT INTO user_details(full_name, user_email, user_password, user_points, user_status, user_type, user_team) VALUES(?, ?, ?, ?, ?,?, ?)"; PreparedStatement statement =
     * connection.prepareStatement(sql);
     * 
     * int count = 0;
     * 
     * // rowIterator.next(); // skip the header row
     * 
     * while (rowIterator.hasNext()) { Row nextRow = rowIterator.next(); Iterator<Cell> cellIterator = nextRow.cellIterator();
     * 
     * while (cellIterator.hasNext()) { Cell nextCell = cellIterator.next(); int columnIndex = nextCell.getColumnIndex();
     * 
     * switch (columnIndex) { case 0: String full_name = nextCell.getStringCellValue(); statement.setString(1, full_name.trim().toUpperCase()); break; case 1: String email_id =
     * nextCell.getStringCellValue(); statement.setString(2, email_id.trim().toLowerCase()); break; }
     * 
     * } statement.setString(3, RandomRange.generateRandom()); statement.setInt(4, 1000); statement.setString(5, "ACTIVE"); statement.setString(6, "PLAYER"); statement.setString(7, "SG11");
     * statement.executeUpdate(); } // connection.close(); workbook.close(); long end = System.currentTimeMillis(); System.out.printf("Import done in %d ms\n", (end - start));
     * 
     * } catch (IOException ex1) { System.out.println("Error reading file"); ex1.printStackTrace(); } catch (SQLException ex2) { System.out.println("Database error"); ex2.printStackTrace(); }
     */

  }
}
