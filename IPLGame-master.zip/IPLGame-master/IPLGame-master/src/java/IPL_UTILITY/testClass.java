/*
 * To change this template, choose Tools | Templates and open the template in the editor.
 */
package IPL_UTILITY;

/**
 *
 * @author Abhinav Kumar
 */
public class testClass
{
  public static void main(String args[])
  {
    int percentageNBU = (int) Math.floor((15868 * 5) / 100);
    System.out.println(percentageNBU);
  }
}
