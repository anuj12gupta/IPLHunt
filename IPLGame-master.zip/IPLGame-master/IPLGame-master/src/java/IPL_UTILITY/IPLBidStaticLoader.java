package IPL_UTILITY;

import IPL_ENUMS.MINMAX;
import IPL_ENUMS.PlayerType;

public class IPLBidStaticLoader
{
  static boolean isMailConfigured;
  static boolean localDBConnection;

  private static final int wicketKeeperMinimumSelection = 1;
  private static final int wicketKeeperMaximumSelection = 4;

  private static final int batsmanMinimumSelection = 3;
  private static final int batsmanMaximumSelection = 6;

  private static final int allrounderMinimumSelection = 1;
  private static final int allrounderMaximumSelection = 4;

  private static final int bowlerMinimumSelection = 3;
  private static final int bowlerMaximumSelection = 6;

  private static final int maximumPlayerFromTeam = 7;

  public static boolean isMailConfigured()
  {
    return isMailConfigured;
  }

  public static boolean localDBConnection()
  {
    return localDBConnection;
  }

  public static int getPlayerTypeMinMaxSelection(PlayerType type, MINMAX selection)
  {
    switch (type)
    {
      case WICKETKEEPER:
        if (selection == MINMAX.MINIMUM)
          return wicketKeeperMinimumSelection;
        else if (selection == MINMAX.MAXIMUM)
          return wicketKeeperMaximumSelection;
        break;

      case BATSMAN:
        if (selection == MINMAX.MINIMUM)
          return batsmanMinimumSelection;
        else if (selection == MINMAX.MAXIMUM)
          return batsmanMaximumSelection;
        break;

      case ALLROUNDER:
        if (selection == MINMAX.MINIMUM)
          return allrounderMinimumSelection;
        else if (selection == MINMAX.MAXIMUM)
          return allrounderMaximumSelection;
        break;

      case BOWLER:
        if (selection == MINMAX.MINIMUM)
          return bowlerMinimumSelection;
        else if (selection == MINMAX.MAXIMUM)
          return bowlerMaximumSelection;
        break;
    }
    return 0;
  }

  public static int getMaxPlayerFromTeam()
  {
    return maximumPlayerFromTeam;
  }

  static
  {
    isMailConfigured = true;
    localDBConnection = false;
  }
}