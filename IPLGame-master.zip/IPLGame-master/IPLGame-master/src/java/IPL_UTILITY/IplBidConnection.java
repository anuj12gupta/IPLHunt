/*
 * To change this template, choose Tools | Templates and open the template in the editor.
 */
package IPL_UTILITY;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author abhinav
 */
public class IplBidConnection
{

  public static Connection openConnection()
  {
    Connection con = null;
    try
    {
      String connectionURL = null;
      if (IPLBidStaticLoader.localDBConnection())
        connectionURL = "jdbc:mysql://localhost:3306/iplhuntc_iplbidding";
      else
        connectionURL = "jdbc:mysql://198.38.82.203:3306/iplhuntc_iplbidding?serverTimezone=UTC";
      Class.forName("com.mysql.cj.jdbc.Driver");
      if (IPLBidStaticLoader.localDBConnection())
        con = DriverManager.getConnection(connectionURL, "root", "");
      else
        con = DriverManager.getConnection(connectionURL, "iplhuntc_iplhunt", "Mysql@9889");
    }
    catch (Exception ex)
    {
      System.out.println("MyConnection:openConnection: Error in opening" + " connection with DB is \n" + ex);
    }
    return con;
  }

  public static void main(String args[])
  {
    System.out.println(IplBidConnection.openConnection());
  }
}
