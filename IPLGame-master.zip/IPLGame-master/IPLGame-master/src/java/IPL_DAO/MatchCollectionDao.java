/*
 * To change this template, choose Tools | Templates and open the template in the editor.
 */
package IPL_DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import IPL_BEANS.MatchCollection;

/**
 *
 * @author Abhinav Kumar
 */
public class MatchCollectionDao
{

  MatchCollection collectionBean;
  public Statement stmt;
  public ResultSet result;
  public Connection con;

  public MatchCollectionDao()
  {
  }

  public MatchCollectionDao(MatchCollection collectionBean)
  {
    this.collectionBean = collectionBean;
  }

  public MatchCollection getCollectionBean()
  {
    return collectionBean;
  }

  public void setCollectionBean(MatchCollection collectionBean)
  {
    this.collectionBean = collectionBean;
  }

  public ResultSet getUserOpenMatchBidPoints()
  {
    String query = "SELECT UD.USER_ID UID,UD.USER_EMAIL,UD.FULL_NAME,UD.USER_TEAM," + "UD.USER_STATUS,UD.USER_POINTS,UD.USER_TYPE, IFNULL(SUM(MC.AMOUNT),'0') BID_POINTS "
                   + "FROM user_details UD LEFT JOIN match_collection MC  " + "ON MC.USER_ID = UD.USER_ID " + "AND MC.COL_STATUS = 'BID OPEN'" + "GROUP BY UD.USER_ID "
                   + "ORDER BY UD.USER_POINTS DESC";
    try
    {
      result = stmt.executeQuery(query);
    }
    catch (SQLException sqlException)
    {
      System.out.println("MatchCollectionDao:getUserOpenMatchCollection: Exception occured " + "while fetching collection for open match and user, Please check below message "
                         + "for more details : \n" + sqlException);
    }
    return result;

  }

  public ResultSet getUserListByApne11Points()
  {
    String query = "SELECT USER_ID, FULL_NAME, USER_APNE11_POINTS FROM user_details where USER_TYPE <> 'ADMIN' order by USER_APNE11_POINTS desc";
    try
    {
      result = stmt.executeQuery(query);
    }
    catch (SQLException sqlException)
    {
      System.out.println("MatchCollectionDao:getUserListByApne11Points: Exception occured " + "while fetching collection for open match and user, Please check below message " + "for more details : \n"
                         + sqlException);
    }
    return result;

  }

  public ResultSet getUserLosedPoints()
  {
    String query = "SELECT IFNULL(SUM(MC.AMOUNT),'0') From match_collection MC " + "WHERE MC.USER_ID = " + collectionBean.getUserID() + " AND MC.COL_STATUS = 'LOSS'";
    try
    {
      result = stmt.executeQuery(query);
    }
    catch (SQLException sqlException)
    {
      System.out.println("MatchCollectionDao:getUserLosedPoints: Exception occured " + "while fetching collection for losed points and user, Please check below message " + "for more details : \n"
                         + sqlException);
    }
    return result;
  }

  public ResultSet getUserEarnedPoints()
  {
    String query = "SELECT IFNULL( SUM( TRX.TRX_AMOUNT ) , '0' ) FROM user_trx_history TRX " + "WHERE TRX.USER_ID = " + collectionBean.getUserID().trim() + " AND (TRX.TRX_TITLE LIKE 'BIDDING-GAIN%' "
                   + "OR TRX.TRX_TITLE LIKE 'QUES-WIN%' OR TRX.TRX_TITLE LIKE 'NBU-BENEFITS%')";
    try
    {
      result = stmt.executeQuery(query);
    }
    catch (SQLException sqlException)
    {
      System.out.println("MatchCollectionDao:getUserEarnedPoints: Exception occured " + "while fetching collection for eared points and user, Please check below message " + "for more details : \n"
                         + sqlException);
    }
    return result;
  }

  public ResultSet getTeamMatchCollection()
  {
    String query = "SELECT MC.*,UD.FULL_NAME FROM match_collection MC , user_details UD " + "WHERE MATCH_ID=" + collectionBean.getMatchID().trim() + " AND BID_TEAM="
                   + collectionBean.getBidTeam().trim() + " AND MC.USER_ID = UD.USER_ID ORDER BY MC.BID_DATE,MC.BID_TIME";
    try
    {
      result = stmt.executeQuery(query);
    }
    catch (SQLException sqlException)
    {
      System.out.println("MatchCollectionDao:getTeamMatchCollection_DAO: Exception occured " + "while fetching collection for match and team, Please check below message " + "for more details : \n"
                         + sqlException);
    }
    return result;
  }

  public ResultSet getUserMatchCollection()
  {
    String query = "SELECT MC.*,UD.FULL_NAME,TD.TEAM_NAME FROM match_collection MC , user_details UD, team_details TD " + "WHERE MC.MATCH_ID=" + collectionBean.getMatchID().trim() + " AND MC.USER_ID="
                   + collectionBean.getUserID().trim() + " AND MC.USER_ID = UD.USER_ID " + " AND MC.BID_TEAM = TD.TEAM_ID ORDER BY MC.BID_DATE,MC.BID_TIME";
    try
    {
      result = stmt.executeQuery(query);
    }
    catch (SQLException sqlException)
    {
      System.out.println("MatchCollectionDao:getUserMatchCollection_DAO: Exception occured " + "while fetching collection for match and user, Please check below message " + "for more details : \n"
                         + sqlException);
    }
    return result;
  }

  public ResultSet getPerTeamMatchCollection()
  {
    String query = "SELECT MC.*,UD.FULL_NAME FROM match_collection MC , user_details UD " + "WHERE MATCH_ID = " + collectionBean.getMatchID().trim() + " AND BID_TEAM = "
                   + collectionBean.getBidTeam().trim() + " AND MC.USER_ID = UD.USER_ID " + " AND UD.USER_TEAM like (SELECT concat('%', USER_TEAM) FROM user_details " + " USR WHERE USR.USER_ID = "
                   + collectionBean.getUserID().trim() + ")" + " ORDER BY MC.BID_DATE,MC.BID_TIME";
    try
    {
      result = stmt.executeQuery(query);
    }
    catch (SQLException sqlException)
    {
      System.out.println("MatchCollectionDao:getTeamMatchCollection_DAO: Exception occured " + "while fetching collection for match and team, Please check below message " + "for more details : \n"
                         + sqlException);
    }
    return result;
  }

  public ResultSet getCollectionDetailsForMatchID()
  {
    String query = "SELECT * FROM match_collection " + "WHERE MATCH_ID = " + collectionBean.getMatchID();
    try
    {
      result = stmt.executeQuery(query);
    }
    catch (SQLException sqlException)
    {
      System.out.println("MatchCollectionDao:getCollectionDetailsForMatchID: Exception occured " + "while fetching collection for eared points and user, Please check below message "
                         + "for more details : \n" + sqlException);
    }
    return result;
  }

  public ResultSet getUserTotalBidPointPerMatch()
  {
    String query = "SELECT IFNULL(SUM(MC.AMOUNT),'0') Total_Point " + "FROM match_collection MC WHERE MC.MATCH_ID = " + collectionBean.getMatchID().trim() + " and MC.USER_ID = "
                   + collectionBean.getUserID().trim();
    try
    {
      result = stmt.executeQuery(query);
    }
    catch (SQLException sqlException)
    {
      System.out.println("MatchCollectionDao:getUserTotalBidPointPerMatch: Exception occured " + "while fetching user points per Match, Please check below message " + "for more details : \n"
                         + sqlException);
    }
    return result;
  }

  public ResultSet getUserBidTeamPerMatch()
  {
    String query = "SELECT distinct(MC.BID_TEAM)" + "FROM match_collection MC WHERE MC.MATCH_ID = " + collectionBean.getMatchID().trim() + " and MC.USER_ID = " + collectionBean.getUserID().trim();
    try
    {
      result = stmt.executeQuery(query);
    }
    catch (SQLException sqlException)
    {
      System.out
          .println("MatchCollectionDao:getUserBidTeamPerMatch: Exception occured " + "while fetching User Bid Team per Match, Please check below message " + "for more details : \n" + sqlException);
    }
    return result;
  }

  public boolean insertMatchCollection()
  {
    boolean returnFlag = false;
    String query = "INSERT INTO match_collection(MATCH_ID,USER_ID,AMOUNT,BID_DATE," + "BID_TIME,BID_TEAM,RESULT_AMOUNT,COL_STATUS) VALUES(" + collectionBean.getMatchID().trim() + ","
                   + collectionBean.getUserID().trim() + "," + collectionBean.getAmount().trim() + ",'" + collectionBean.getBidDate().trim() + "','" + collectionBean.getBidTime().trim() + "',"
                   + collectionBean.getBidTeam().trim() + "," + collectionBean.getResultAmount().trim() + ",'" + collectionBean.getColStatus().trim().toUpperCase() + "')";
    try
    {

      if (stmt.executeUpdate(query) != 0)
      {
        returnFlag = true;
      }
    }
    catch (SQLException sqlException)
    {
      System.out.println("MatchCollectionDao:insertMatchCollection_DAO: Exception occured " + "while inserting match collection details, Please check below message " + "for more details : \n"
                         + sqlException);
    }
    return returnFlag;
  }

  public boolean deleteMatchCollectionEXP()
  {
    boolean checkFlag = false;
    String query = "DELETE FROM match_collection WHERE" + " MATCH_ID = " + collectionBean.getMatchID().trim() + " AND USER_ID = " + collectionBean.getUserID().trim() + " AND AMOUNT = "
                   + collectionBean.getAmount().trim() + " AND BID_DATE = '" + collectionBean.getBidDate().trim() + "' " + " AND BID_TIME = '" + collectionBean.getBidTime().trim() + "' "
                   + " AND BID_TEAM = " + collectionBean.getBidTeam().trim() + " AND RESULT_AMOUNT = " + collectionBean.getResultAmount() + " AND COL_STATUS = '" + collectionBean.getColStatus() + "'";
    try
    {
      stmt.executeUpdate(query);
      checkFlag = true;
    }
    catch (SQLException sqlException)
    {
      System.out.println("MatchCollectionDao:deleteMatchCollectionEXP: Exception occured " + "while deleting collection details, Please check below message " + "for more details : \n" + sqlException);
    }
    return checkFlag;
  }

  public boolean updateResultAndStatusAmount()
  {
    boolean checkFlag = false;
    String query = "UPDATE match_collection " + " SET RESULT_AMOUNT=" + collectionBean.getResultAmount().trim() + " ,COL_STATUS = '" + collectionBean.getColStatus().trim().toUpperCase()
                   + "' WHERE COLLECTION_ID=" + collectionBean.getCollectionID().trim();
    try
    {
      stmt.executeUpdate(query);
      checkFlag = true;
    }
    catch (SQLException sqlException)
    {
      System.out.println("MatchCollectionDao:updateResultAmount_DAO: Exception occured " + "while updating result amount, Please check below message " + "for more details : \n" + sqlException);
    }
    return checkFlag;
  }

  public ResultSet getDistinctBidUserForMatchID()
  {
    String query = "SELECT DISTINCT USER_ID, MATCH_ID FROM match_collection " + "WHERE MATCH_ID = " + collectionBean.getMatchID();
    try
    {
      result = stmt.executeQuery(query);
    }
    catch (SQLException sqlException)
    {
      System.out.println("MatchCollectionDao:getDistinctBidUserForMatchID: Exception occured " + "while fetching collection for distinct user id, Please check below message " + "for more details : \n"
                         + sqlException);
    }
    return result;
  }

  public ResultSet getUnBidUserDetails()
  {
    String query = "SELECT UD.* FROM user_details UD  " + "WHERE UD.USER_ID NOT IN( SELECT MC.USER_ID FROM match_collection MC " + "WHERE MATCH_ID = " + collectionBean.getMatchID().trim() + ")"
                   + " AND USER_STATUS = 'ACTIVE' " + "AND USER_TYPE = 'PLAYER' " + "AND UD.USER_POINTS > 0";
    try
    {
      result = stmt.executeQuery(query);
    }
    catch (SQLException sqlException)
    {
      System.out.println("MatchCollectionDao:getUnBidUserDetails: Exception occured " + "while fetching non bid user details, Please check below message " + "for more details : \n" + sqlException);
    }
    return result;
  }

  public ResultSet getTotalTeamCollection()
  {
    String query = "SELECT USER_TEAM as TEAM_NAME, sum(USER_POINTS) as TEAM_POINT, " + "count(*) as TEAM_COUNT FROM user_details WHERE USER_STATUS = 'ACTIVE' GROUP BY USER_TEAM";
    try
    {
      result = stmt.executeQuery(query);
    }
    catch (SQLException sqlException)
    {
      System.out.println("MatchCollectionDao:getTotalTeamCollection_DAO: Exception occured " + "while fetching total collection and team, Please check below message " + "for more details : \n"
                         + sqlException);
    }
    return result;
  }

  public boolean insertDataForGraph()
  {
    boolean returnFlag = false;
    String query = "INSERT INTO match_graph_data(match_id, team_id, team_amount, team_count) VALUES (" + collectionBean.getMatchID() + ",'" + collectionBean.getWinTeamID() + "'" + ",'"
                   + collectionBean.getAmount() + "'" + ",'" + collectionBean.getResultAmount() + "')";
    try
    {
      if (stmt.executeUpdate(query) != 0)
      {
        returnFlag = true;
      }
    }
    catch (SQLException sqlException)
    {
      System.out
          .println("MatchCollectionDao:insertDataForGraph_DAO: Exception occured " + "while inserting data regarding graph, Please check below message " + "for more details : \n" + sqlException);
    }
    return returnFlag;
  }
}
