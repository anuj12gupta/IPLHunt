package IPL_DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import IPL_UTILITY.IplBidConnection;

public class Apne11Dao
{
  public Statement stmt;
  public ResultSet result;
  public Connection con;

  public Apne11Dao()
  {
    try
    {
      con = IplBidConnection.openConnection();
      stmt = con.createStatement();
    }
    catch (Exception ex)
    {
      System.out.println("Apne11Dao:Default_Constructor: Error Occured while " + "opening connection \n" + ex);
    }
  }

  public ResultSet getUserApne11TeamForMatch(String matchId, String userId)
  {
    String query = "SELECT * FROM apne11_player_teams WHERE USER_ID = " + userId.trim() + " AND MATCH_ID = " + matchId.trim();
    try
    {
      result = stmt.executeQuery(query);
    }
    catch (SQLException sqlException)
    {
      System.out.println("Apne11Dao:getUserApne11TeamForMatch: Exception occured " + "while fetching team player list for apne 11 contest, Please check below message " + "for more details : \n"
                         + sqlException);
    }
    return result;
  }

  public int saveApne11Entry(String matchId, String userId, String playerIds[])
  {
    String query =
      "INSERT INTO apne11_player_teams(MATCH_ID, USER_ID, PLAYER_1_ID, PLAYER_2_ID, PLAYER_3_ID, PLAYER_4_ID, PLAYER_5_ID, PLAYER_6_ID, PLAYER_7_ID, PLAYER_8_ID, PLAYER_9_ID, PLAYER_10_ID, PLAYER_11_ID, CAPTAIN_ID, VCAPTAIN_ID, TOTAL_POINTS) VALUES("
                   + matchId.trim() + "," + userId.trim() + "," + playerIds[0].trim() + "," + playerIds[1].trim() + "," + playerIds[2].trim() + "," + playerIds[3].trim() + "," + playerIds[4].trim()
                   + "," + playerIds[5].trim() + "," + playerIds[6].trim() + "," + playerIds[7].trim() + "," + playerIds[8].trim() + "," + playerIds[9].trim() + "," + playerIds[10].trim() + ","
                   + playerIds[11].trim() + "," + playerIds[12].trim() + ",'0')";
    int count = 0;
    try
    {
      count = stmt.executeUpdate(query);
    }
    catch (SQLException sqlException)
    {
      System.out.println("Apne11Dao:saveApne11Entry: Exception occured " + " While inserting entry for apne11 contest, Please check below message " + "for more details : \n" + sqlException);
    }
    return count;
  }

  public int updateApne11Entry(String matchId, String userId, String playerIds[])
  {
    String query = "UPDATE apne11_player_teams SET PLAYER_1_ID = " + playerIds[0].trim() + ", PLAYER_2_ID = " + playerIds[1].trim() + ", PLAYER_3_ID = " + playerIds[2].trim() + ", PLAYER_4_ID = "
                   + playerIds[3].trim() + ", PLAYER_5_ID = " + playerIds[4].trim() + ", PLAYER_6_ID = " + playerIds[5].trim() + ", PLAYER_7_ID = " + playerIds[6].trim() + ", PLAYER_8_ID = "
                   + playerIds[7].trim() + ", PLAYER_9_ID = " + playerIds[8].trim() + ", PLAYER_10_ID = " + playerIds[9].trim() + ", PLAYER_11_ID = " + playerIds[10].trim() + ", CAPTAIN_ID = "
                   + playerIds[11].trim() + ", VCAPTAIN_ID = " + playerIds[12].trim() + " WHERE MATCH_ID = " + matchId.trim() + " AND USER_ID = " + userId.trim();
    int count = 0;
    try
    {
      count = stmt.executeUpdate(query);
    }
    catch (SQLException sqlException)
    {
      System.out.println("Apne11Dao:updateApne11Entry: Exception occured " + " While updating" + " entry for apne11 contest, Please check below message " + "for more details : \n" + sqlException);
    }
    return count;
  }

  public int updateApne11TeamPoints(String matchId, String userId, String points)
  {
    String query = "UPDATE apne11_player_teams SET TOTAL_POINTS = '" + points.trim() + "'  WHERE MATCH_ID = " + matchId.trim() + " AND USER_ID = " + userId.trim();
    int count = 0;
    try
    {
      count = stmt.executeUpdate(query);
    }
    catch (SQLException sqlException)
    {
      System.out.println("updateApne11TeamPoints: Exception occured  While updating Team Points for apne11 contest, Please check below message " + "for more details : \n" + sqlException);
    }
    return count;
  }

  public ResultSet getApne11RegisteredTeamForMatch(String matchId)
  {
    String query = "SELECT * FROM apne11_player_teams WHERE MATCH_ID = " + matchId.trim();
    try
    {
      result = stmt.executeQuery(query);
    }
    catch (SQLException sqlException)
    {
      System.out.println("Apne11Dao:getApne11RegisteredTeamForMatch: Exception occured " + "while fetching team player list for apne 11 contest, Please check below message " + "for more details : \n"
                         + sqlException);
    }
    return result;
  }

  public int saveApne11Result(String matchId, String playerId, double playerPoints, int playingStatus)
  {
    String query =
      "INSERT INTO apne11_match_result(MATCH_ID, PLAYER_ID, PLAYER_EARN_POINTS, PLAYER_PLAYING) " + "VALUE(" + matchId.trim() + "," + playerId.trim() + "," + playerPoints + "," + playingStatus + ")";

    int count = 0;
    try
    {
      count = stmt.executeUpdate(query);
    }
    catch (SQLException sqlException)
    {
      System.out
          .println("Apne11Dao:saveApne11Result: Exception occured " + " While inserting player points for apne11 match result, Please check below message " + "for more details : \n" + sqlException);
    }
    return count;
  }

  public ResultSet getApne11TeamResult(String matchId, String teamId)
  {
    String query = "SELECT amr.PLAYER_ID, amr.PLAYER_EARN_POINTS, amr.PLAYER_PLAYING, tpd.PLAYER_NAME, tpd.PLAYER_TYPE FROM "
                   + "apne11_match_result amr, team_player_detail tpd WHERE amr.PLAYER_ID = tpd.PLAYER_ID " + "and MATCH_ID = " + matchId.trim() + " and tpd.TEAM_ID = " + teamId.trim()
                   + " ORDER BY amr.PLAYER_EARN_POINTS DESC";
    try
    {
      result = stmt.executeQuery(query);
    }
    catch (SQLException sqlException)
    {
      System.out
          .println("Apne11Dao:getApne11TeamResult: Exception occured " + "while fetching team player list for apne 11 contest, Please check below message " + "for more details : \n" + sqlException);
    }
    return result;
  }

  public ResultSet getApne11UsersTeamForMatch(String matchId)
  {
    String query =
      "SELECT apt.*, ud.FULL_NAME FROM apne11_player_teams apt, user_details ud WHERE " + "apt.MATCH_ID = " + matchId.trim() + " and apt.USER_ID = ud.USER_ID ORDER BY apt.TOTAL_POINTS DESC";
    try
    {
      result = stmt.executeQuery(query);
    }
    catch (SQLException sqlException)
    {
      System.out.println("Apne11Dao:getApne11UsersTeamForMatch: Exception occured " + "while fetching team player list for apne 11 contest, Please check below message " + "for more details : \n"
                         + sqlException);
    }
    return result;
  }

}
