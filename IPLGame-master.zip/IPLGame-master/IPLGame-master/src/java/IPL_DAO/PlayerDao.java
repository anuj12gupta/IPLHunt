package IPL_DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import IPL_BEANS.Player;
import IPL_UTILITY.IplBidConnection;

public class PlayerDao
{
  Player player;
  public Statement stmt;
  public ResultSet result;
  public Connection con;

  public PlayerDao()
  {
    try
    {
      con = IplBidConnection.openConnection();
      stmt = con.createStatement();
    }
    catch (Exception ex)
    {
      System.out.println("PlayerDao:Default_Constructor: Error Occured while " + "opening connection \n" + ex);
    }
  }

  public PlayerDao(Player player)
  {
    this.player = player;
    try
    {
      con = IplBidConnection.openConnection();
      stmt = con.createStatement();
    }
    catch (Exception ex)
    {
      System.out.println("PlayerDao:Constructor: Error Occured while " + "opening connection \n" + ex);
    }
  }

  public ResultSet getPlayingPlayerListOfMatch(String teamId1, String teamId2)
  {
    String query = "SELECT td.TEAM_CODE, td.TEAM_NAME, tpd.* FROM team_player_detail tpd, team_details td WHERE tpd.TEAM_ID IN (" + teamId1.trim() + "," + teamId2.trim()
                   + ") AND tpd.PLAYER_POINT > 0 AND tpd.TEAM_ID = td.TEAM_ID ORDER BY tpd.PLAYER_POINT DESC";
    try
    {
      result = stmt.executeQuery(query);
    }
    catch (SQLException sqlException)
    {
      System.out
          .println("PlayerDao:getPlayingPlayerListOfMatch: Exception occured " + "while fetching team player list by team id, Please check below message " + "for more details : \n" + sqlException);
    }
    return result;
  }

  public ResultSet getPlayerListOfTeam(String teamId)
  {
    String query = "SELECT td.TEAM_CODE, td.TEAM_NAME, tpd.* FROM team_player_detail tpd, team_details td WHERE tpd.TEAM_ID IN (" + teamId.trim()
                   + ") AND tpd.PLAYER_POINT > 0 AND tpd.TEAM_ID = td.TEAM_ID ORDER BY tpd.PLAYER_POINT DESC";
    try
    {
      result = stmt.executeQuery(query);
    }
    catch (SQLException sqlException)
    {
      System.out.println("PlayerDao:getPlayerListOfTeam: Exception occured " + "while fetching team player list by team id, Please check below message " + "for more details : \n" + sqlException);
    }
    return result;
  }

  public int updatePlayerPlayingStatus(String playerId, String playingStatus)
  {
    String query = "UPDATE team_player_detail SET PLAYER_PLAYING =" + playingStatus.trim() + " WHERE PLAYER_ID = " + playerId.trim();

    int count = 0;
    try
    {
      count = stmt.executeUpdate(query);
    }
    catch (SQLException sqlException)
    {
      System.out.println("PlayerDao:updatePlayerPlayingStatus: Exception occured " + " While updating player playing status, Please check below message " + "for more details : \n" + sqlException);
    }
    return count;
  }
}
