package IPL_ENUMS;

public enum PlayerType
{
  WICKETKEEPER, BATSMAN, ALLROUNDER, BOWLER
}
