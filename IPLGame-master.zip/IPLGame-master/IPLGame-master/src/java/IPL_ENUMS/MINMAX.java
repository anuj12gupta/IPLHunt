package IPL_ENUMS;

public enum MINMAX
{
  MINIMUM, MAXIMUM
}
