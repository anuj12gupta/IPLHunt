function openCity(evt, cityName) {
	var i, tabcontent, tablinks;
	tabcontent = document.getElementsByClassName("tabcontent");
	for (i = 0; i < tabcontent.length; i++) {
		tabcontent[i].style.display = "none";
	}
	tablinks = document.getElementsByClassName("tablinks");
	for (i = 0; i < tablinks.length; i++) {
		tablinks[i].className = tablinks[i].className.replace(" active", "");
	}
	document.getElementById(cityName).style.display = "block";
	evt.currentTarget.className += " active";
}

var wkpPlayer = [0,0,0,0];
var wkpTeamCodes = ["N","N","N","N"];
var wkpPlayerPoints = [0.0,0.0,0.0,0.0];
var wkpPlayerNames = ["P","P","P","P"];
var wkpPlayerPlaying = [false,false,false,false];

var btmPlayer = [0,0,0,0,0,0];
var btmTeamCodes = ["N","N","N","N","N","N"];
var btmPlayerPoints = [0.0,0.0,0.0,0.0,0.0,0.0];
var btmPlayerNames = ["P","P","P","P","P","P"];
var btmPlayerPlaying = [false,false,false,false,false,false];

var alrPlayer = [0,0,0,0];
var alrTeamCodes = ["N","N","N","N"];
var alrPlayerPoints = [0.0,0.0,0.0,0.0];
var alrPlayerNames = ["P","P","P","P"];
var alrPlayerPlaying = [false,false,false,false];

var bowPlayer = [0,0,0,0,0,0];
var bowTeamCodes = ["N","N","N","N","N","N"];
var bowPlayerPoints = [0.0,0.0,0.0,0.0,0.0,0.0];
var bowPlayerNames = ["P","P","P","P","P","P"];
var bowPlayerPlaying = [false,false,false,false,false,false];

var wkpCount = 0;
var wkpMinCount = 1;
var wkpMaxCount = 4;

var btmCount = 0;
var btmMinCount = 3;
var btmMaxCount = 6;

var alrCount = 0;
var alrMinCount = 1;
var alrMaxCount = 4;

var bowCount = 0;
var bowMinCount = 3;
var bowMaxCount = 6;

var team1Code = "";
var team2Code = "";
var team1Count = 0;
var team2Count = 0;
var totalCount = 0;
var totalCreditUsed = 0.0;
var totalRemainingCredit = 0.0;

var captainId = 0;
var viceCaptainId = 0;

function apne11Completed()
{
	var ctnBtn = document.getElementById("contBtn");
    var classPresent = ctnBtn.className;
	if(totalCount == 11)
	{
		disableTeamPlayers(team1Code);
		disableTeamPlayers(team2Code);
		console.log(classPresent);
		if(classPresent == "disableContinue")
		{
			ctnBtn.classList.remove("disableContinue");
			ctnBtn.className += "enableContinue";
			ctnBtn.disabled=false;
		}
	}
	else
    {
		if(classPresent == "enableContinue")
		{
			ctnBtn.classList.remove("enableContinue");
			ctnBtn.className += "disableContinue";
			ctnBtn.disabled=true;
		}
    }
}


function enableTeamPlayers(teamCode)
{
	var tableTeamCode = "";
	var table = document.getElementById("wkpTable");
	for (var i = 0, row; row = table.rows[i]; i++) {
		tableTeamCode = row.cells[0].innerHTML;  
		if(tableTeamCode == teamCode)
		{
			var rowSelected = table.getElementsByTagName('tr')[i];
			var disabledPresent = rowSelected.classList.contains("disabled");
			rowSelected.classList.remove('disabled');
			if(disabledPresent)
			{
				var selectButton = table.getElementsByTagName('button')[i];
				selectButton.classList.remove("disabledBtn");
			}
		}
	}
	
	
	table = document.getElementById("btmTable");
	for (var i = 0, row; row = table.rows[i]; i++) {
		tableTeamCode = row.cells[0].innerHTML;  
		if(tableTeamCode == teamCode)
		{
			var rowSelected = table.getElementsByTagName('tr')[i];
			var disabledPresent = rowSelected.classList.contains("disabled");
			rowSelected.classList.remove('disabled');
			if(disabledPresent)
			{
				var selectButton = table.getElementsByTagName('button')[i];
				selectButton.classList.remove("disabledBtn");
			}
		}
	}
	
	
	table = document.getElementById("alrTable");
	for (var i = 0, row; row = table.rows[i]; i++) {
		tableTeamCode = row.cells[0].innerHTML;  
		if(tableTeamCode == teamCode)
		{
			var rowSelected = table.getElementsByTagName('tr')[i];
			var disabledPresent = rowSelected.classList.contains("disabled");
			rowSelected.classList.remove('disabled');
			if(disabledPresent)
			{
				var selectButton = table.getElementsByTagName('button')[i];
				selectButton.classList.remove("disabledBtn");
			}
		}
	}
	
	table = document.getElementById("bowTable");
	for (var i = 0, row; row = table.rows[i]; i++) {
		tableTeamCode = row.cells[0].innerHTML;  
		if(tableTeamCode == teamCode)
		{
			var rowSelected = table.getElementsByTagName('tr')[i];
			var disabledPresent = rowSelected.classList.contains("disabled");
			rowSelected.classList.remove('disabled');
			if(disabledPresent)
			{
				var selectButton = table.getElementsByTagName('button')[i];
				selectButton.classList.remove("disabledBtn");
			}
		}
	}
}


function disableTeamPlayers(teamCode)
{
	var tableTeamCode = "";
	var table = document.getElementById("wkpTable");
	for (var i = 0, row; row = table.rows[i]; i++) {
		tableTeamCode = row.cells[0].innerHTML;  
		if(tableTeamCode == teamCode)
		{
			var rowSelected = table.getElementsByTagName('tr')[i];
			var selectedPresent = rowSelected.classList.contains("selected");
			var disabledPresent = rowSelected.classList.contains("disabled");
			if(!(selectedPresent || disabledPresent))
			{
				rowSelected.className += " disabled";
				var selectButton = table.getElementsByTagName('button')[i];
				selectButton.className += " disabledBtn";
			}
		}
	}
	
	
	table = document.getElementById("btmTable");
	for (var i = 0, row; row = table.rows[i]; i++) {
		tableTeamCode = row.cells[0].innerHTML;  
		if(tableTeamCode == teamCode)
		{
			var rowSelected = table.getElementsByTagName('tr')[i];
			var selectedPresent = rowSelected.classList.contains("selected");
			var disabledPresent = rowSelected.classList.contains("disabled");
			if(!(selectedPresent || disabledPresent))
			{
				rowSelected.className += " disabled";
				var selectButton = table.getElementsByTagName('button')[i];
				selectButton.className += " disabledBtn";
			}
		}
	}
	
	
	table = document.getElementById("alrTable");
	for (var i = 0, row; row = table.rows[i]; i++) {
		tableTeamCode = row.cells[0].innerHTML;  
		if(tableTeamCode == teamCode)
		{
			var rowSelected = table.getElementsByTagName('tr')[i];
			var selectedPresent = rowSelected.classList.contains("selected");
			var disabledPresent = rowSelected.classList.contains("disabled");
			if(!(selectedPresent || disabledPresent))
			{
				rowSelected.className += " disabled";
				var selectButton = table.getElementsByTagName('button')[i];
				selectButton.className += " disabledBtn";
			}
		}
	}
	
	table = document.getElementById("bowTable");
	for (var i = 0, row; row = table.rows[i]; i++) {
		tableTeamCode = row.cells[0].innerHTML;  
		if(tableTeamCode == teamCode)
		{
			var rowSelected = table.getElementsByTagName('tr')[i];
			var selectedPresent = rowSelected.classList.contains("selected");
			var disabledPresent = rowSelected.classList.contains("disabled");
			if(!(selectedPresent || disabledPresent))
			{
				rowSelected.className += " disabled";
				var selectButton = table.getElementsByTagName('button')[i];
				selectButton.className += " disabledBtn";
			}
		}
	}
}


function handleMaxPlayerVisibility()
{
	if(team1Count >= 7)
	{
		disableTeamPlayers(team1Code);
	}
	else
	{
		enableTeamPlayers(team1Code);
	}
	if(team2Count >= 7)
	{
		disableTeamPlayers(team2Code);
	}
	else
	{
		enableTeamPlayers(team2Code);
	}
}

function handleLowerCreditVisibility()
{
	var tableCellPoint= 0.0;
	var table = document.getElementById("wkpTable");
	for (var i = 0, row; row = table.rows[i]; i++) {
		tableCellPoint = row.cells[2].innerHTML;  
		if(tableCellPoint > totalRemainingCredit)
		{
			var rowSelected = table.getElementsByTagName('tr')[i];
			var selectedPresent = rowSelected.classList.contains("selected");
			var disabledPresent = rowSelected.classList.contains("disabled");
			if(!(selectedPresent || disabledPresent))
			{
				rowSelected.className += " disabled";
				var selectButton = table.getElementsByTagName('button')[i];
				selectButton.className += " disabledBtn";
			}
		}
		
		
		
		
	}
	
	table = document.getElementById("btmTable");
	for (var i = 0, row; row = table.rows[i]; i++) {
		tableCellPoint = row.cells[2].innerHTML;  
		if(tableCellPoint > totalRemainingCredit)
		{
			var rowSelected = table.getElementsByTagName('tr')[i];
			var selectedPresent = rowSelected.classList.contains("selected");
			var disabledPresent = rowSelected.classList.contains("disabled");
			if(!(selectedPresent || disabledPresent))
			{
				rowSelected.className += " disabled";
				var selectButton = table.getElementsByTagName('button')[i];
				selectButton.className += " disabledBtn";
			}
		}
	}
	
	
	table = document.getElementById("alrTable");
	for (var i = 0, row; row = table.rows[i]; i++) {
		tableCellPoint = row.cells[2].innerHTML;  
		if(tableCellPoint > totalRemainingCredit)
		{
			var rowSelected = table.getElementsByTagName('tr')[i];
			var selectedPresent = rowSelected.classList.contains("selected");
			var disabledPresent = rowSelected.classList.contains("disabled");
			if(!(selectedPresent || disabledPresent))
			{
				rowSelected.className += " disabled";
				var selectButton = table.getElementsByTagName('button')[i];
				selectButton.className += " disabledBtn";
			}
		}
	}
	
	
	table = document.getElementById("bowTable");
	for (var i = 0, row; row = table.rows[i]; i++) {
		tableCellPoint = row.cells[2].innerHTML;  
		if(tableCellPoint > totalRemainingCredit)
		{
			var rowSelected = table.getElementsByTagName('tr')[i];
			var selectedPresent = rowSelected.classList.contains("selected");
			var disabledPresent = rowSelected.classList.contains("disabled");
			if(!(selectedPresent || disabledPresent))
			{
				rowSelected.className += " disabled";
				var selectButton = table.getElementsByTagName('button')[i];
				selectButton.className += " disabledBtn";
			}
		}
	}
}

function disableWkpContent()
{
	var table = document.getElementById("wkpTable");
	for (var i = 0, row; row = table.rows[i]; i++) {
	  var rowSelected = table.getElementsByTagName('tr')[i];
      var selectedPresent = rowSelected.classList.contains("selected");
	  var disabledPresent = rowSelected.classList.contains("disabled");
	  if(!(selectedPresent || disabledPresent))
	  {
		  rowSelected.className += " disabled";
		  var selectButton = table.getElementsByTagName('button')[i];
		  selectButton.className += " disabledBtn";
	  }
		
	}
}

function disableBtmContent()
{
	var table = document.getElementById("btmTable");
	for (var i = 0, row; row = table.rows[i]; i++) {
	  var rowSelected = table.getElementsByTagName('tr')[i];
      var selectedPresent = rowSelected.classList.contains("selected");
	  var disabledPresent = rowSelected.classList.contains("disabled");
	  if(!(selectedPresent || disabledPresent))
	  {
		  rowSelected.className += " disabled";
		  var selectButton = table.getElementsByTagName('button')[i];
		  selectButton.className += " disabledBtn";
	  }
		
	}
}

function disableAlrContent()
{
	var table = document.getElementById("alrTable");
	for (var i = 0, row; row = table.rows[i]; i++) {
	  var rowSelected = table.getElementsByTagName('tr')[i];
      var selectedPresent = rowSelected.classList.contains("selected");
	  var disabledPresent = rowSelected.classList.contains("disabled");
	  if(!(selectedPresent || disabledPresent))
	  {
		  rowSelected.className += " disabled";
		  var selectButton = table.getElementsByTagName('button')[i];
		  selectButton.className += " disabledBtn";
	  }
		
	}
}

function disableBowContent()
{
	var table = document.getElementById("bowTable");
	for (var i = 0, row; row = table.rows[i]; i++) {
	  var rowSelected = table.getElementsByTagName('tr')[i];
      var selectedPresent = rowSelected.classList.contains("selected");
	  var disabledPresent = rowSelected.classList.contains("disabled");
	  if(!(selectedPresent || disabledPresent))
	  {
		  rowSelected.className += " disabled";
		  var selectButton = table.getElementsByTagName('button')[i];
		  selectButton.className += " disabledBtn";
	  }
		
	}
}

function handleCategoryMinMaxVisibility()
{
	var totalRemainingCount = 11 - totalCount;
	
	var totalBowRequired = 0;
	var totalBtmRequired = 0;
	var totalAlrRequired = 0;
	var totalWkpRequired = 0;
	
	if(bowCount < bowMinCount)
	{
		totalBowRequired = bowMinCount - bowCount;
	}
	
	if(btmCount < btmMinCount)
	{
		totalBtmRequired = btmMinCount - btmCount;
	}
	
	if(alrCount < alrMinCount)
	{
		totalAlrRequired = alrMinCount - alrCount;
	}
	
	if(wkpCount < wkpMinCount)
	{
		totalWkpRequired = wkpMinCount - wkpCount;
	}
	
	if((totalBowRequired + totalBtmRequired + totalAlrRequired + totalWkpRequired) >= totalRemainingCount)
	{
		document.getElementById("errorMessageDiv").style.display = "none";
		document.getElementById("errorMessageDiv").innerHTML = "";
		if(bowCount < bowMinCount)
		{
			document.getElementById("errorMessageDiv").style.display = "block";
			document.getElementById("errorMessageDiv").innerHTML = "Select minimum 3 Bowlers";
			disableWkpContent();
			disableBtmContent();
			disableAlrContent();
		}
		else if(btmCount < btmMinCount)
		{
			document.getElementById("errorMessageDiv").style.display = "block";
			document.getElementById("errorMessageDiv").innerHTML = "Select minimum 3 BatsMan";
			disableWkpContent();
			disableAlrContent();
			disableBowContent();
		}
		else if(alrCount < alrMinCount)
		{
			document.getElementById("errorMessageDiv").style.display = "block";
			document.getElementById("errorMessageDiv").innerHTML = "Select minimum 1 Allrounder";
			disableWkpContent();
			disableBtmContent();
			disableBowContent();
		}
		else if(wkpCount < wkpMinCount)
		{
			document.getElementById("errorMessageDiv").style.display = "block";
			document.getElementById("errorMessageDiv").innerHTML = "Select minimum 1 WicketKeeper";
			disableBtmContent();
			disableAlrContent();
			disableBowContent();
		}
	}
	else
	{
		document.getElementById("errorMessageDiv").innerHTML = "";
		document.getElementById("errorMessageDiv").style.display = "none";
	}
	
	if(bowCount == bowMaxCount)
	{
		disableBowContent();
	}
	
	if(btmCount == btmMaxCount)
	{
		disableBtmContent();
	}
	
	if(wkpCount == wkpMaxCount)
	{
		disableWkpContent();
	}
	
	if(alrCount == alrMaxCount)
	{
		disableAlrContent();
	}
}

function handleTabContentVisibility()
{
	handleMaxPlayerVisibility();
}

function displayHeaderCounts()
{	
	document.getElementById("t1Count").innerHTML = team1Count;
	document.getElementById("t2Count").innerHTML = team2Count;
	
	document.getElementById("wkpCnt").innerHTML = wkpCount;
	document.getElementById("btmCnt").innerHTML = btmCount;
	document.getElementById("alrCnt").innerHTML = alrCount;
	document.getElementById("bowCnt").innerHTML = bowCount;
	
	
    totalCount = team1Count + team2Count;
	document.getElementById("totCount").innerHTML = totalCount+"/"+11;
	totalRemainingCredit = (100.0 - totalCreditUsed);
	document.getElementById("creditPoints").innerHTML = totalRemainingCredit;
}

function fillHeaderCounts()
{	
	team1Count = document.getElementById("t1Count").innerHTML;
	team2Count = document.getElementById("t2Count").innerHTML;
	
	wkpCount = document.getElementById("wkpCnt").innerHTML;
	btmCount = document.getElementById("btmCnt").innerHTML;
	alrCount = document.getElementById("alrCnt").innerHTML;
	bowCount = document.getElementById("bowCnt").innerHTML;
	
	totalRemainingCredit = document.getElementById("creditPoints").innerHTML;
	totalCount = 11;
	team1Code = document.getElementById("t1Code").innerHTML;
	team2Code = document.getElementById("t2Code").innerHTML;
		
}

function performHeaderCalculation()
{
	team1Count = 0;
	team2Count = 0;
	
	wkpCount = 0;
	btmCount = 0;
	alrCount = 0;
	bowCount = 0;
	totalCreditUsed = 0.0;
	for(var i = 0; i < wkpTeamCodes.length; i++)
	{
		if(wkpTeamCodes[i] == team1Code)
		{
			team1Count = team1Count + 1;
			totalCreditUsed = totalCreditUsed + parseFloat(wkpPlayerPoints[i]);
		}
		else if(wkpTeamCodes[i] == team2Code)
		{
			team2Count = team2Count + 1;
			totalCreditUsed = totalCreditUsed + parseFloat(wkpPlayerPoints[i]);
		}
	}
	wkpCount = team1Count + team2Count;
	for(i = 0; i < btmTeamCodes.length; i++)
	{
		if(btmTeamCodes[i] == team1Code)
		{
			team1Count = team1Count + 1;
			totalCreditUsed = totalCreditUsed + parseFloat(btmPlayerPoints[i]);
		}
		else if(btmTeamCodes[i] == team2Code)
		{
			team2Count = team2Count + 1;
			totalCreditUsed = totalCreditUsed + parseFloat(btmPlayerPoints[i]);
		}
	}
	btmCount = (team1Count + team2Count) - wkpCount;
	for(i = 0; i < alrTeamCodes.length; i++)
	{
		if(alrTeamCodes[i] == team1Code)
		{
			team1Count = team1Count + 1;
			totalCreditUsed = totalCreditUsed + parseFloat(alrPlayerPoints[i]);
		}
		else if(alrTeamCodes[i] == team2Code)
		{
			team2Count = team2Count + 1;
			totalCreditUsed = totalCreditUsed + parseFloat(alrPlayerPoints[i]);
		}
	}
	alrCount = (team1Count + team2Count) - (wkpCount + btmCount);
	for(i = 0; i < bowTeamCodes.length; i++)
	{
		if(bowTeamCodes[i] == team1Code)
		{
			team1Count = team1Count + 1;
			totalCreditUsed = totalCreditUsed + parseFloat(bowPlayerPoints[i]);
		}
		else if(bowTeamCodes[i] == team2Code)
		{
			team2Count = team2Count + 1;
			totalCreditUsed = totalCreditUsed + parseFloat(bowPlayerPoints[i]);
		}
	}
	bowCount = (team1Count + team2Count) - (wkpCount + btmCount + alrCount);
	displayHeaderCounts();
}

function incrementProgressBar()
{
	var progressValue = document.getElementById("progressBar").value;
	if(progressValue < 11)
	{
		progressValue = progressValue + 1;
		document.getElementById("progressBar").value = progressValue;
	}
}

function decrementProgressBar()
{
	var progressValue = document.getElementById("progressBar").value;
	if(progressValue > 0 )
	{
		progressValue = progressValue - 1;
		document.getElementById("progressBar").value = progressValue;
	}
}

function addWkpPlayer(playerId, teamCode, PlayerPoints, playerName, isPlaying)
{
	var isAdded = 0;
	for (var i = 0; i < wkpPlayer.length; i++) {
		var plId = wkpPlayer[i];
		if (plId == 0 ) {
			wkpPlayer[i] = playerId;
			wkpTeamCodes[i] = teamCode;
			wkpPlayerPoints[i] = parseFloat(PlayerPoints);
			wkpPlayerNames[i] = playerName;
			wkpPlayerPlaying[i] = isPlaying;
			isAdded = 1;
			incrementProgressBar();
			break;
		}
	}
}
function removeWkpPlayer(playerId, teamCode)
{
	var isRemoved = 0;
	for (var i = 0; i < wkpPlayer.length; i++) {
		var plId = wkpPlayer[i];
		if (plId == playerId) {
			wkpPlayer[i] = 0;
			wkpTeamCodes[i] = "N";
			wkpPlayerPoints[i] = 0.0;
			wkpPlayerNames[i] = "P";
			wkpPlayerPlaying[i] = false;
			isRemoved = 1;
			decrementProgressBar();
			break;
		}
	}
}

function addBtmPlayer(playerId, teamCode, PlayerPoints, playerName, isPlaying)
{
	var isAdded = 0;
	for (var i = 0; i < btmPlayer.length; i++) {
		var plId = btmPlayer[i];
		if (plId == 0 ) {
			btmPlayer[i] = playerId;
			btmTeamCodes[i] = teamCode;
			btmPlayerPoints[i] = parseFloat(PlayerPoints);
			btmPlayerNames[i] = playerName;
			btmPlayerPlaying[i] = isPlaying;
			isAdded = 1;
			incrementProgressBar();
			break;
		}
	}
}
function removeBtmPlayer(playerId, teamCode)
{
	var isRemoved = 0;
	for (var i = 0; i < btmPlayer.length; i++) {
		var plId = btmPlayer[i];
		if (plId == playerId) {
			btmPlayer[i] = 0;
			btmTeamCodes[i] = "N";
			btmPlayerPoints[i] = 0.0;
			btmPlayerNames[i] = "P";
			btmPlayerPlaying[i] = false;
			isRemoved = 1;
			decrementProgressBar();
			break;
		}
	}
}



function addAlrPlayer(playerId, teamCode, PlayerPoints, playerName, isPlaying)
{
	var isAdded = 0;
	for (var i = 0; i < alrPlayer.length; i++) {
		var plId = alrPlayer[i];
		if (plId == 0 ) {
			alrPlayer[i] = playerId;
			alrTeamCodes[i] = teamCode;
			alrPlayerPoints[i] = parseFloat(PlayerPoints);
			alrPlayerNames[i] = playerName;
			alrPlayerPlaying[i] = isPlaying;
			isAdded = 1;
			incrementProgressBar();
			break;
		}
	}
}
function removeAlrPlayer(playerId, teamCode)
{
	var isRemoved = 0;
	for (var i = 0; i < alrPlayer.length; i++) {
		var plId = alrPlayer[i];
		if (plId == playerId) {
			alrPlayer[i] = 0;
			alrTeamCodes[i] = "N";
			alrPlayerPoints[i] = 0.0;
			alrPlayerNames[i] = "P";
			alrPlayerPlaying[i] = false;
			isRemoved = 1;
			decrementProgressBar();
			break;
		}
	}
}


function addBowPlayer(playerId, teamCode, PlayerPoints, playerName, isPlaying)
{
	var isAdded = 0;
	for (var i = 0; i < bowPlayer.length; i++) {
		var plId = bowPlayer[i];
		if (plId == 0 ) {
			bowPlayer[i] = playerId;
			bowTeamCodes[i] = teamCode;
			bowPlayerPoints[i] = parseFloat(PlayerPoints);
			bowPlayerNames[i] = playerName;
			bowPlayerPlaying[i] = isPlaying;
			isAdded = 1;
			incrementProgressBar();
			break;
		}
	}
}
function removeBowPlayer(playerId, teamCode)
{
	var isRemoved = 0;
	for (var i = 0; i < bowPlayer.length; i++) {
		var plId = bowPlayer[i];
		if (plId == playerId) {
			bowPlayer[i] = 0;
			bowTeamCodes[i] = "N";
			bowPlayerPoints[i] = 0.0;
			bowPlayerNames[i] = "P";
			bowPlayerPlaying[i] = false;
			isRemoved = 1;
			decrementProgressBar();
			break;
		}
	}
}

function selDeselPlayer(x, counter, tableid, playerId, teamCode, playerPoint, playerName, isPlaying) {
	team1Code = document.getElementById("t1Code").innerHTML;
	team2Code = document.getElementById("t2Code").innerHTML;
		
	var table = document.getElementById(tableid);
	x.classList.toggle("fa-minus");
	var rowSelected = table.getElementsByTagName('tr')[counter];
	var classPresent = rowSelected.className;
	if (classPresent == "selected") {
		rowSelected.classList.remove('selected');
		if (tableid == "wkpTable") {
			removeWkpPlayer(playerId, teamCode);
		}
		else if (tableid == "btmTable")
		{
			removeBtmPlayer(playerId, teamCode);
		}
		else if (tableid == "alrTable")
		{
			removeAlrPlayer(playerId, teamCode);
		}
		else if (tableid == "bowTable")
		{
			removeBowPlayer(playerId, teamCode);
		}

	} else {
		
		rowSelected.className += "selected";
		if (tableid == "wkpTable") {
			addWkpPlayer(playerId, teamCode, playerPoint, playerName, isPlaying);
		}
		else if (tableid == "btmTable")
		{
			addBtmPlayer(playerId, teamCode, playerPoint, playerName, isPlaying);
		}
		else if (tableid == "alrTable")
		{
			addAlrPlayer(playerId, teamCode, playerPoint, playerName, isPlaying);
		}
		else if (tableid == "bowTable")
		{
			addBowPlayer(playerId, teamCode, playerPoint, playerName, isPlaying)
		}
	}
	displayHeaderCounts();
	performHeaderCalculation();
	handleTabContentVisibility();
	handleLowerCreditVisibility();
	handleCategoryMinMaxVisibility();
	apne11Completed();
}

function arrayToList()
{
	var table = document.getElementById("playerDetailTable");
	var serialNumber = 0;
	
	for(i = 0 ; i < 24; i++)
	{
		if(i == 0 || i == 5 || i == 12 || i == 17)
			continue;
		
		if(i == 1)
		{
			for(j = 0; j < 4; j++)
			{
				var rowSelected = table.getElementsByTagName('tr')[i + j];
				
				if(wkpTeamCodes[j] == "N")
				{
					rowSelected.cells[0].innerHTML = "";
					rowSelected.cells[1].innerHTML = "";
					rowSelected.cells[2].innerHTML = "";
					rowSelected.cells[3].innerHTML = ""; 
					rowSelected.cells[4].innerHTML = "";
					rowSelected.cells[5].innerHTML = "";
					rowSelected.cells[6].innerHTML = ""; 
					document.getElementById("wkp"+(j+1)+"id").value = "";
				}
				else
				{
					console.log("Value = " +  wkpPlayerPlaying[j]);
					serialNumber = serialNumber + 1;
					rowSelected.cells[0].innerHTML = "" + serialNumber;
					rowSelected.cells[1].innerHTML = "" + wkpTeamCodes[j];
					rowSelected.cells[2].innerHTML = "" + wkpPlayerNames[j];
					rowSelected.cells[3].innerHTML = "" + wkpPlayerPoints[j];
					if(wkpPlayerPlaying[j] == true)
					{
						rowSelected.cells[4].innerHTML = "<div><img src='../Images/purple_dot.png' style='width:10px; heigth:10px;'/> <span>Played last match</span></div>";
					}
					else
					{
						rowSelected.cells[4].innerHTML = "";
					}
					rowSelected.cells[5].innerHTML = "<input type='radio' name='captain' value='"+ wkpPlayer[j] +"' onclick='selectCaptain(this.value)' />";
					rowSelected.cells[6].innerHTML = "<input type='radio' name='viceCaptain' value='"+ wkpPlayer[j] +"' onclick='selectViceCaptain(this.value)' />";
					document.getElementById("wkp"+(j+1)+"id").value = wkpPlayer[j];
				}
			}
		}
		if(i == 6)
		{
			
			for(j = 0; j < 6; j++)
			{
				var rowSelected = table.getElementsByTagName('tr')[i + j];
				if(btmTeamCodes[j] == "N")
				{
					rowSelected.cells[0].innerHTML = "";
					rowSelected.cells[1].innerHTML = "";
					rowSelected.cells[2].innerHTML = "";
					rowSelected.cells[3].innerHTML = ""; 
					rowSelected.cells[4].innerHTML = "";
					rowSelected.cells[5].innerHTML = "";
					rowSelected.cells[6].innerHTML = ""; 
					document.getElementById("btm"+(j+1)+"id").value = "";
				}
				else
				{
					serialNumber = serialNumber + 1;
					rowSelected.cells[0].innerHTML = "" + serialNumber;  
					rowSelected.cells[1].innerHTML = "" + btmTeamCodes[j];
					rowSelected.cells[2].innerHTML = "" + btmPlayerNames[j];
					rowSelected.cells[3].innerHTML = "" + btmPlayerPoints[j];
					if(btmPlayerPlaying[j] == true)
					{
						rowSelected.cells[4].innerHTML = "<div><img src='../Images/purple_dot.png' style='width:10px; heigth:10px;'/> <span>Played last match</span></div>";
					}
					else
					{
						rowSelected.cells[4].innerHTML = "";
					}
					rowSelected.cells[5].innerHTML = "<input type='radio' name='captain' value='"+ btmPlayer[j]+"' onclick='selectCaptain(this.value)'/>";
					rowSelected.cells[6].innerHTML = "<input type='radio' name='viceCaptain' value='" +btmPlayer[j]+"' onclick='selectViceCaptain(this.value)' />";
					document.getElementById("btm"+(j+1)+"id").value = btmPlayer[j];
				}
				
			}
		}
		if(i == 13)
		{
			
			for(j = 0; j < 4; j++)
			{
				var rowSelected = table.getElementsByTagName('tr')[i + j];
				if(alrTeamCodes[j] == "N")
				{
					rowSelected.cells[0].innerHTML = "";
					rowSelected.cells[1].innerHTML = "";
					rowSelected.cells[2].innerHTML = "";
					rowSelected.cells[3].innerHTML = ""; 
					rowSelected.cells[4].innerHTML = "";
					rowSelected.cells[5].innerHTML = "";
					rowSelected.cells[6].innerHTML = ""; 
					document.getElementById("alr"+(j+1)+"id").value = "";
				}
				else
				{
					serialNumber = serialNumber + 1;
					rowSelected.cells[0].innerHTML = "" + serialNumber;  
					rowSelected.cells[1].innerHTML = "" + alrTeamCodes[j];
					rowSelected.cells[2].innerHTML = "" + alrPlayerNames[j];
					rowSelected.cells[3].innerHTML = "" + alrPlayerPoints[j];
					if(alrPlayerPlaying[j] == true)
					{
						rowSelected.cells[4].innerHTML = "<div><img src='../Images/purple_dot.png' style='width:10px; heigth:10px;'/> <span>Played last match</span></div>";
					}
					else
					{
						rowSelected.cells[4].innerHTML = "";
					}
					rowSelected.cells[5].innerHTML = "<input type='radio' name='captain' value='" + alrPlayer[j]+ "' onclick='selectCaptain(this.value)'/>";
					rowSelected.cells[6].innerHTML = "<input type='radio' name='viceCaptain' value='" + alrPlayer[j] + "' onclick='selectViceCaptain(this.value)'/>";
					document.getElementById("alr"+(j+1)+"id").value = alrPlayer[j];
				}
				
			}
		}
		
		if(i == 18)
		{
			
			for(j = 0; j < 6; j++)
			{
				var rowSelected = table.getElementsByTagName('tr')[i + j];
				if(bowTeamCodes[j] == "N")
				{
					rowSelected.cells[0].innerHTML = "";
					rowSelected.cells[1].innerHTML = "";
					rowSelected.cells[2].innerHTML = "";
					rowSelected.cells[3].innerHTML = ""; 
					rowSelected.cells[4].innerHTML = "";
					rowSelected.cells[5].innerHTML = "";
					rowSelected.cells[6].innerHTML = ""; 
					document.getElementById("bow"+(j+1)+"id").value = "";
				}
				else
				{
					serialNumber = serialNumber + 1;
					rowSelected.cells[0].innerHTML = "" + serialNumber;  
					rowSelected.cells[1].innerHTML = "" + bowTeamCodes[j];
					rowSelected.cells[2].innerHTML = "" + bowPlayerNames[j];
					rowSelected.cells[3].innerHTML = "" + bowPlayerPoints[j];
					if(bowPlayerPlaying[j] == true)
					{
						rowSelected.cells[4].innerHTML = "<div><img src='../Images/purple_dot.png' style='width:10px; heigth:10px;'/> <span>Played last match</span></div>";
					}
					else
					{
						rowSelected.cells[4].innerHTML = "";
					}
					rowSelected.cells[5].innerHTML = "<input type='radio' name='captain' value='" + bowPlayer[j]+ "' onclick='selectCaptain(this.value)'/>";
					rowSelected.cells[6].innerHTML = "<input type='radio' name='viceCaptain' value='" +bowPlayer[j]+ "' onclick='selectViceCaptain(this.value)'/>";
					document.getElementById("bow"+(j+1)+"id").value = bowPlayer[j];
				}
				
			}
		}
		
	}
}

function nextStepToSelection()
{
	var divList = document.getElementById("listPanel");
	var divTabs = document.getElementById("tabPanel");
	var divPlayerList = document.getElementById("playerList");
	
	var divProgress = document.getElementById("progressDiv");
	var divUpdatePanel = document.getElementById("updatePanel");
	
	divTabs.style.display ="none";
	divList.style.display ="block";
	divPlayerList.style.display ="block";
	
	console.log(divProgress);
	console.log(divUpdatePanel);
	
	divProgress.style.display ="none";
	divUpdatePanel.style.display ="block";
	
	arrayToList();
	
	var rgsBtn = document.getElementById("registerBtn");
	var rgsclassPresent = rgsBtn.className;
	
	if(rgsclassPresent == "enableContinue")
	{
		rgsBtn.classList.remove("enableContinue");
		rgsBtn.className += "disableContinue";
	}
}

function selectCaptain(cid)
{
	captainId = cid;
	var errorDiv = document.getElementById("errorMessageDiv");
	var ctnBtn = document.getElementById("registerBtn");
	var classPresent = ctnBtn.className;
	if(viceCaptainId != 0 && captainId == viceCaptainId)
	{
		errorDiv.style.display="block";
		errorDiv.innerHTML = "Captain and Vice Captain cannot be same";
		if(classPresent == "enableContinue")
		{
			ctnBtn.classList.remove("enableContinue");
			ctnBtn.className += "disableContinue";
		}
	}
	else if(viceCaptainId != 0 && captainId != 0 && captainId != viceCaptainId)
	{
		errorDiv.style.display="none";
		if(classPresent == "disableContinue")
		{
			ctnBtn.classList.remove("disableContinue");
			ctnBtn.className += "enableContinue";
		}
	}
	else if( captainId != 0 && viceCaptainId == 0)
	{
		errorDiv.style.display="block";
		errorDiv.innerHTML = "Select Vice Captain to continue";
		if(classPresent != "disableContinue")
		{
			ctnBtn.classList.remove("enableContinue");
			ctnBtn.className += "disableContinue";
		}		
	}
}

function selectViceCaptain(vid)
{
	viceCaptainId = vid;
	var errorDiv = document.getElementById("errorMessageDiv");
	var ctnBtn = document.getElementById("registerBtn");
	var classPresent = ctnBtn.className;
	
	if(captainId != 0 && viceCaptainId == captainId)
	{
		errorDiv.style.display="block";
		errorDiv.innerHTML = "Captain and Vice Captain cannot be same";
		if(classPresent == "enableContinue")
		{
			ctnBtn.classList.remove("enableContinue");
			ctnBtn.className += "disableContinue";
		}
	}
	else if(captainId != 0 && viceCaptainId != 0 && viceCaptainId != captainId)
	{
		errorDiv.style.display="none";
		if(classPresent == "disableContinue")
		{
			ctnBtn.classList.remove("disableContinue");
			ctnBtn.className += "enableContinue";
		}
	}
	else if( viceCaptainId != 0 && captainId == 0)
	{
		errorDiv.style.display="block";
		errorDiv.innerHTML = "Select Captain to continue";
		if(classPresent != "disableContinue")
		{
			ctnBtn.classList.remove("enableContinue");
			ctnBtn.className += "disableContinue";
		}
	}
}

function listToArray()
{
	var table = document.getElementById("playerDetailTable");
	var serialNumber = 0;
	
	for(i = 0 ; i < 24; i++)
	{
		if(i == 0 || i == 5 || i == 12 || i == 17)
			continue;
		
		if(i == 1)
		{
			for(j = 0; j < 4; j++)
			{
				var rowSelected = table.getElementsByTagName('tr')[i + j];
				var teamCode = rowSelected.cells[1].innerHTML;
				if(teamCode == "")
				{
					wkpPlayer[j] = 0;
					wkpTeamCodes[j] = "N";
					wkpPlayerPoints[j] = 0.0;
					wkpPlayerNames[j] = "P";
					wkpPlayerPlaying[j] = false;
				}
				else
				{
					
					var wkpid = document.getElementById("wkp" + (j + 1) +"id").value;
					wkpPlayer[j] = wkpid;
					wkpTeamCodes[j] = teamCode;
					wkpPlayerPoints[j] = rowSelected.cells[3].innerHTML;
					wkpPlayerNames[j] = rowSelected.cells[2].innerHTML;
					var playingStatus = rowSelected.cells[4].innerHTML
					if(playingStatus == "")
						wkpPlayerPlaying[j] = false;
					else
						wkpPlayerPlaying[j] = true;
				}
			}
		}
		if(i == 6)
		{
			
			for(j = 0; j < 6; j++)
			{
				var rowSelected = table.getElementsByTagName('tr')[i + j];
				var teamCode = rowSelected.cells[1].innerHTML;
				if(teamCode == "")
				{
					btmPlayer[j] = 0;
					btmTeamCodes[j] = "N";
					btmPlayerPoints[j] = 0.0;
					btmPlayerNames[j] = "P";
					btmPlayerPlaying[j] = false;
				}
				else
				{
					var btmid = document.getElementById("btm" + (j + 1) +"id").value;
					btmPlayer[j] = btmid;
					btmTeamCodes[j] = teamCode;
					btmPlayerPoints[j] = rowSelected.cells[3].innerHTML;
					btmPlayerNames[j] = rowSelected.cells[2].innerHTML;
					var playingStatus = rowSelected.cells[4].innerHTML
					if(playingStatus == "")
						btmPlayerPlaying[j] = false;
					else
						btmPlayerPlaying[j] = true;
				}
			}
		}
		if(i == 13)
		{
			
			for(j = 0; j < 4; j++)
			{
				var rowSelected = table.getElementsByTagName('tr')[i + j];
				var teamCode = rowSelected.cells[1].innerHTML;
				if(teamCode == "")
				{
					alrPlayer[j] = 0;
					alrTeamCodes[j] = "N";
					alrPlayerPoints[j] = 0.0;
					alrPlayerNames[j] = "P";
					alrPlayerPlaying[j] = false;
				}
				else
				{
					var alrid = document.getElementById("alr" + (j + 1) +"id").value;
					alrPlayer[j] = alrid;
					alrTeamCodes[j] = teamCode;
					alrPlayerPoints[j] = rowSelected.cells[3].innerHTML;
					alrPlayerNames[j] = rowSelected.cells[2].innerHTML;
					var playingStatus = rowSelected.cells[4].innerHTML
					if(playingStatus == "")
						alrPlayerPlaying[j] = false;
					else
						alrPlayerPlaying[j] = true;
				}
				
			}
		}
		
		if(i == 18)
		{
			
			for(j = 0; j < 6; j++)
			{
				var rowSelected = table.getElementsByTagName('tr')[i + j];
				var teamCode = rowSelected.cells[1].innerHTML;
				if(teamCode == "")
				{
					bowPlayer[j] = 0;
					bowTeamCodes[j] = "N";
					bowPlayerPoints[j] = 0.0;
					bowPlayerNames[j] = "P";
					bowPlayerPlaying[j] = false;
				}
				else
				{
					var bowid = document.getElementById("bow" + (j + 1) +"id").value;
					bowPlayer[j] = bowid;
					bowTeamCodes[j] = teamCode;
					bowPlayerPoints[j] = rowSelected.cells[3].innerHTML;
					bowPlayerNames[j] = rowSelected.cells[2].innerHTML;
					var playingStatus = rowSelected.cells[4].innerHTML
					if(playingStatus == "")
						bowPlayerPlaying[j] = false;
					else
						bowPlayerPlaying[j] = true;
				}
				
			}
		}
		
	}
}

function backStepToSelection()
{
	var divList = document.getElementById("listPanel");
	var divTabs = document.getElementById("tabPanel");
	var divPlayerList = document.getElementById("playerList");
	
	var divProgress = document.getElementById("progressDiv");
	var divUpdatePanel = document.getElementById("updatePanel");
	
	divTabs.style.display ="block";
	divList.style.display ="none";
	divPlayerList.style.display ="none";
	
	divProgress.style.display ="block";
	divUpdatePanel.style.display ="none";
	
	listToArray();
	fillHeaderCounts();
	//displayHeaderCounts();
	//performHeaderCalculation();
	handleTabContentVisibility();
	handleLowerCreditVisibility();
	handleCategoryMinMaxVisibility();
	apne11Completed();
}

function checkApne11Form()
{
	var errorDiv = document.getElementById("errorMessageDiv");
	if(captainId == 0 || viceCaptainId == 0)
	{
		errorDiv.style.display="block";
		errorDiv.innerHTML = "Select Captain and Vice-Captain to proceed";
		return false;
	}
	else
    {
		errorDiv.style.display="none";
		errorDiv.innerHTML = "";
		return true;
	}
}